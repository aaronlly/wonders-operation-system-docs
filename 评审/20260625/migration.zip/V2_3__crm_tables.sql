-- =====================================================
-- V2_3: CRM Tables
--
-- Schema: crm
-- Purpose: Sales/CRM data for prospect management,
--          communication tracking, conversion pipeline,
--          task management, and student CRM profile.
--
-- Tables:
--   1. crm.prospect
--   2. crm.communication
--   3. crm.tag
--   4. crm.tag_assignment
--   5. crm.conversion_stage
--   6. crm.conversion
--   7. crm.task
--   8. crm.student_profile
-- =====================================================

-- =====================================================
-- 1. Prospect (Lead/Customer Pipeline)
-- Absorbs old prospect.prospect table.
-- entity_type = 'prospect' for self-reference.
-- =====================================================
CREATE TABLE crm.prospect (
    id                          UUID                        PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id              UUID                        NOT NULL,
    legal_full_name             TEXT                        NOT NULL,
    preferred_name              TEXT,
    guardian_name               TEXT,
    guardian_gender             VARCHAR(10),
    guardian_date_of_birth      DATE,
    guardian_nationality        TEXT,
    guardian_phone              TEXT,
    guardian_email              TEXT,
    guardian_wechat             TEXT,
    guardian_address            TEXT,
    guardian_relationship_type  VARCHAR(30),
    date_of_birth               DATE,
    nationality                 TEXT,
    religion                    TEXT,

    primary_phone               TEXT                        NOT NULL,
    email                       TEXT,
    wechat_id                   TEXT,
    address                     TEXT,

    grade_of_next_academic_year TEXT,
    day_school                  TEXT,
    day_school_grade            TEXT,
    source                      TEXT                        NOT NULL,
    source_courses              TEXT,
    source_language             TEXT,
    source_url                  TEXT,
    source_channel              TEXT,
    user_agent                  TEXT,
    ip_address                  TEXT,
    notes                       TEXT,

    status                      VARCHAR(20)                 NOT NULL DEFAULT 'new'
        CHECK (status IN (
            'new','contacted','trial_booked','trial_completed',
            'negotiating','qualified','converted','lost','dropped'
        )),

    assigned_to                 UUID,
    created_by                  UUID,
    converted_to_person_id      UUID,
    converted_at                TIMESTAMPTZ,
    contacted_at                TIMESTAMPTZ,
    status_updated_at           TIMESTAMPTZ,
    created_at                  TIMESTAMPTZ                 NOT NULL DEFAULT now(),
    updated_at                  TIMESTAMPTZ                 NOT NULL DEFAULT now(),

    CONSTRAINT fk_prospect_institution
        FOREIGN KEY (institution_id) REFERENCES org.education_institution(id)
);

CREATE INDEX idx_prospect_status ON crm.prospect(status);
CREATE INDEX idx_prospect_assigned ON crm.prospect(assigned_to);
CREATE INDEX idx_prospect_institution ON crm.prospect(institution_id);
CREATE INDEX idx_prospect_phone ON crm.prospect(primary_phone);

-- Prospect guardians (additional beyond the first guardian embedded in prospect)
CREATE TABLE crm.prospect_guardian (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    prospect_id         UUID            NOT NULL REFERENCES crm.prospect(id) ON DELETE CASCADE,
    guardian_name       TEXT            NOT NULL,
    guardian_gender     VARCHAR(10),
    guardian_date_of_birth DATE,
    guardian_nationality TEXT,
    guardian_phone      TEXT,
    guardian_email      TEXT,
    guardian_wechat     TEXT,
    guardian_address    TEXT,
    relationship_type   VARCHAR(30),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_prospect_guardian_prospect ON crm.prospect_guardian(prospect_id);

-- =====================================================
-- 2. Communication (polymorphic interaction records)
-- entity_type: 'prospect', 'student', 'guardian', 'marketing_activity', 'sales_contract'
-- type: 'email', 'call', 'meeting', 'note', 'sms'
-- institution-scoped for multi-tenant data isolation.
-- =====================================================
CREATE TABLE crm.communication (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    entity_type     VARCHAR(30)     NOT NULL
        CHECK (entity_type IN ('prospect','student','guardian','marketing_activity','sales_contract')),
    entity_id       UUID            NOT NULL,
    type            VARCHAR(20)     NOT NULL
        CHECK (type IN ('email','call','meeting','note','sms')),
    subject         TEXT,
    content         TEXT,
    direction       VARCHAR(10)     NOT NULL DEFAULT 'outbound'
        CHECK (direction IN ('inbound','outbound')),
    email_log_id    UUID,
    created_by      UUID            NOT NULL,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT fk_comm_email_log
        FOREIGN KEY (email_log_id) REFERENCES email.email_log(id)
);

CREATE INDEX idx_comm_institution_entity ON crm.communication(institution_id, entity_type, entity_id);
CREATE INDEX idx_comm_type ON crm.communication(type);
CREATE INDEX idx_comm_created ON crm.communication(created_at DESC);

-- =====================================================
-- 3. Tag (tag definitions, institution-scoped)
-- type: 'prospect', 'student', 'activity', 'contract'
-- =====================================================
CREATE TABLE crm.tag (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    name            VARCHAR(100)    NOT NULL,
    color           VARCHAR(7)      NOT NULL DEFAULT '#1890ff',
    type            VARCHAR(30)     NOT NULL DEFAULT 'student'
        CHECK (type IN ('prospect','student','activity','contract')),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_tag_institution_name_type UNIQUE (institution_id, name, type)
);

-- =====================================================
-- 4. Tag Assignment (polymorphic)
-- entity_type: 'prospect', 'student', 'activity', 'contract'
-- =====================================================
CREATE TABLE crm.tag_assignment (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    tag_id          UUID            NOT NULL REFERENCES crm.tag(id) ON DELETE CASCADE,
    entity_type     VARCHAR(30)     NOT NULL
        CHECK (entity_type IN ('prospect','student','activity','contract')),
    entity_id       UUID            NOT NULL,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_tag_assignment UNIQUE (tag_id, entity_type, entity_id)
);

CREATE INDEX idx_tag_assign_entity ON crm.tag_assignment(entity_type, entity_id);
CREATE INDEX idx_tag_assign_tag ON crm.tag_assignment(tag_id);

-- =====================================================
-- 5. Conversion Stage (sales pipeline stages, institution-scoped)
-- =====================================================
CREATE TABLE crm.conversion_stage (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    name            VARCHAR(100)    NOT NULL,
    display_order   INT             NOT NULL,
    color           VARCHAR(7)      NOT NULL DEFAULT '#1890ff',
    probability     INT             NOT NULL DEFAULT 0
        CHECK (probability >= 0 AND probability <= 100),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_stage_institution_order UNIQUE (institution_id, display_order)
);

-- =====================================================
-- 6. Conversion (deal/opportunity tracking, institution-scoped)
-- Tracks the conversion of a prospect/student through the pipeline.
-- entity_type: 'prospect', 'student'
-- =====================================================
CREATE TABLE crm.conversion (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    entity_type         VARCHAR(30)     NOT NULL
        CHECK (entity_type IN ('prospect','student')),
    entity_id           UUID            NOT NULL,
    stage_id            UUID            REFERENCES crm.conversion_stage(id),
    amount              DECIMAL(12,2)   DEFAULT 0,
    probability         INT             CHECK (probability >= 0 AND probability <= 100),
    expected_close_date DATE,
    assigned_to         UUID,
    notes               TEXT,
    created_by          UUID,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_conversion_institution ON crm.conversion(institution_id, entity_type, entity_id);
CREATE INDEX idx_conversion_stage ON crm.conversion(stage_id);
CREATE INDEX idx_conversion_assigned ON crm.conversion(assigned_to);

-- =====================================================
-- 7. Task (polymorphic task tracking)
-- related_to_type: 'prospect', 'student', 'conversion', 'contract', 'activity'
-- =====================================================
CREATE TABLE crm.task (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    title           VARCHAR(255)    NOT NULL,
    description     TEXT,
    due_date        TIMESTAMPTZ,
    priority        VARCHAR(10)     NOT NULL DEFAULT 'medium'
        CHECK (priority IN ('low','medium','high','urgent')),
    status          VARCHAR(15)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','in_progress','completed','cancelled')),
    related_to_type VARCHAR(30)
        CHECK (related_to_type IN ('prospect','student','conversion','contract','activity')),
    related_to_id   UUID,
    assigned_to     UUID,
    reminder_at     TIMESTAMPTZ,
    completed_at    TIMESTAMPTZ,
    created_by      UUID            NOT NULL,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_task_related ON crm.task(related_to_type, related_to_id);
CREATE INDEX idx_task_assigned ON crm.task(assigned_to);
CREATE INDEX idx_task_status ON crm.task(status);
CREATE INDEX idx_task_due ON crm.task(due_date);

-- =====================================================
-- 8. Student Profile (CRM extension of org.person, institution-scoped)
-- Additional fields for students managed via CRM.
-- Composite PK (institution_id, person_id) allows the same person
-- to have different CRM profiles across institutions.
-- =====================================================
CREATE TABLE crm.student_profile (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    person_id           UUID            NOT NULL REFERENCES org.person(id) ON DELETE CASCADE,
    grade               TEXT,
    grade_year          INT,
    grade_month         INT,
    day_school          TEXT,
    day_school_grade    TEXT,
    day_school_year     INT,
    day_school_month    INT,
    campus              TEXT,
    taboos              TEXT,
    source              TEXT,
    status              VARCHAR(20)     NOT NULL DEFAULT 'lead'
        CHECK (status IN ('lead','prospect','enrolled','lost','archived')),
    notes               TEXT,
    created_by          UUID            REFERENCES auth.user_account(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),

    UNIQUE (institution_id, person_id),

    CONSTRAINT fk_student_profile_person
        FOREIGN KEY (person_id) REFERENCES org.person(id)
);

CREATE INDEX idx_student_profile_person ON crm.student_profile(person_id);
CREATE INDEX idx_student_profile_status ON crm.student_profile(status);
CREATE INDEX idx_student_profile_institution ON crm.student_profile(institution_id);
