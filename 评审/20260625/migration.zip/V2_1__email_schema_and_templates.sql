-- =====================================================
-- Email Schema and Tables
-- 创建 email schema 和相关表
-- 用途：提供通用的邮件发送和审计功能
-- 适用系统：SAAS_OPERATOR, SCHOOL_WEBSITE 等
-- 创建日期：2026-02-04
-- =====================================================

-- =====================================================
-- 创建 email schema
-- 说明：独立的 schema 用于隔离邮件相关数据
-- =====================================================
CREATE SCHEMA IF NOT EXISTS email;

-- =====================================================
-- 1. 邮件模板表 (email_template)
-- 用途：存储多语言邮件模板，支持变量替换
-- 说明：
--   - 每个业务场景对应一个模板代码 (template_code)
--   - 支持中文(zh)、英文(en)、波兰语(pl)三语
--   - 使用 JSONB 定义模板变量
--   - 可通过 is_active 控制模板启用/禁用
-- =====================================================
CREATE TABLE email.email_template (
	-- 主键：UUID，自动生成
	id                          	UUID 					PRIMARY KEY DEFAULT gen_random_uuid(),
    
	-- 模板代码：唯一标识，如 'PRINCIPAL_CREDENTIALS'
	-- 命名规范：{业务}_{场景}，全大写，下划线分隔
	-- 【注意】不再单独 UNIQUE，改为联合唯一约束
	template_code               	VARCHAR(50) 			NOT NULL,
    
	-- 【新增】机构ID：NULL表示默认模板（全系统通用），有值表示机构专属模板
	institution_id              	UUID 					NULL,
    
	-- 模板名称：便于管理的描述性名称
	template_name               	VARCHAR(100),
    
	-- 邮件主题（三语版本）
	-- 支持模板变量，如：{{username}}，使用 {{isResend}} 标记重发
	subject_zh                  	VARCHAR(255),           -- 中文主题
	subject_en                  	VARCHAR(255),           -- 英文主题
	subject_pl                  	VARCHAR(255),           -- 波兰语主题
    
	-- 邮件正文（三语版本）
	-- 使用 TEXT 类型支持长内容
	-- 支持模板变量替换
	body_zh                     	TEXT,                   -- 中文正文
	body_en                     	TEXT,                   -- 英文正文
	body_pl                     	TEXT,                   -- 波兰语正文
    
	-- 模板变量定义：JSONB 格式
	-- 示例：["username", "password", "loginUrl", "isResend", "institutionName"]
	-- 用于代码中验证和自动补全
	variables                   	JSONB,
    
	-- 是否启用：软删除标记
	-- true = 可用，false = 已禁用
	is_active                   	BOOLEAN 				DEFAULT true,
    
	-- 时间戳：记录创建和更新时间
	created_at                   	TIMESTAMP WITH TIME ZONE 	DEFAULT CURRENT_TIMESTAMP,
	updated_at                   	TIMESTAMP WITH TIME ZONE 	DEFAULT CURRENT_TIMESTAMP
    
	-- 【注意】不设置UNIQUE约束，允许同一模板代码有多个记录（不同机构）
	-- 唯一性由应用层控制：默认模板只有一个（institution_id IS NULL）
	-- 机构模板：template_code + institution_id 组合唯一
);

-- 表和字段注释
COMMENT ON TABLE email.email_template IS '邮件模板表，支持多语言和变量替换。每个业务场景对应一个模板，包含中/英/波三语版本。支持机构专属模板（institution_id 有值）和默认模板（institution_id 为 NULL）。';
COMMENT ON COLUMN email.email_template.id IS '主键：UUID，系统自动生成';
COMMENT ON COLUMN email.email_template.template_code IS '模板唯一代码，命名规范：{业务}_{场景}，如 PRINCIPAL_CREDENTIALS';
COMMENT ON COLUMN email.email_template.institution_id IS '机构ID，NULL表示默认模板（全系统通用），有值表示机构专属模板，关联 org.education_institution.id';
COMMENT ON COLUMN email.email_template.template_name IS '模板显示名称，用于管理界面展示';
COMMENT ON COLUMN email.email_template.subject_zh IS '中文邮件主题，支持 {{变量}} 替换语法';
COMMENT ON COLUMN email.email_template.subject_en IS '英文邮件主题';
COMMENT ON COLUMN email.email_template.subject_pl IS '波兰语邮件主题';
COMMENT ON COLUMN email.email_template.body_zh IS '中文邮件正文，使用 TEXT 类型支持长内容';
COMMENT ON COLUMN email.email_template.body_en IS '英文邮件正文';
COMMENT ON COLUMN email.email_template.body_pl IS '波兰语邮件正文';
COMMENT ON COLUMN email.email_template.variables IS '模板变量定义，JSONB 格式数组，如 ["username", "password", "loginUrl", "isResend", "institutionName"]';
COMMENT ON COLUMN email.email_template.is_active IS '模板启用状态：true=可用，false=已禁用';
COMMENT ON COLUMN email.email_template.created_at IS '模板创建时间';
COMMENT ON COLUMN email.email_template.updated_at IS '模板最后更新时间';

-- 【新增】唯一索引：确保每个机构的模板唯一，且默认模板只有一个
-- 使用 COALESCE 将 NULL 转换为特定 UUID，实现默认模板只有一个
CREATE UNIQUE INDEX idx_email_template_code_institution 
ON email.email_template(template_code, COALESCE(institution_id, '00000000-0000-0000-0000-000000000000'));

COMMENT ON INDEX email.idx_email_template_code_institution IS '联合唯一索引：模板代码 + 机构ID（NULL转为全零UUID），确保每个模板代码在同一机构下只有一个记录';

-- 【新增】普通索引：加速按机构查询模板
CREATE INDEX idx_email_template_institution 
ON email.email_template(institution_id);

COMMENT ON INDEX email.idx_email_template_institution IS '普通索引：加速按机构ID查询模板';

-- 【新增】外键约束：关联到教育机构表
-- V2_0 已经创建了 org.education_institution 表，所以可以安全添加外键
ALTER TABLE email.email_template 
ADD CONSTRAINT fk_email_template_institution 
FOREIGN KEY (institution_id) REFERENCES org.education_institution(id);

COMMENT ON CONSTRAINT fk_email_template_institution ON email.email_template IS '外键约束：关联到教育机构表，确保机构ID有效性';

-- =====================================================
-- 2. 邮件发送日志表 (email_log)
-- 用途：记录所有邮件发送历史，用于审计和故障排查
-- 说明：
--   - 记录完整的邮件内容（主题、正文）
--   - 追踪发送状态：PENDING → RETRYING → SENT/FAILED
--   - 支持5次自动重试，记录每次失败原因
--   - 审计字段记录操作人和来源系统
-- =====================================================
CREATE TABLE email.email_log (
	-- 主键：UUID，每次发送生成唯一ID（即 task_id）
	id                          	UUID 					PRIMARY KEY DEFAULT gen_random_uuid(),
    
	-- 使用的模板代码，关联 email_template
	template_code               	VARCHAR(50) 			NOT NULL,
    
	-- =====================================================
	-- 收件人信息区域
	-- =====================================================
	-- 收件人类型：PRINCIPAL(校长), TEACHER(教师), STUDENT(学生), PARENT(家长)
	recipient_type              	VARCHAR(50),
    
	-- 收件人ID：关联到 org.person 表的主键
	-- 可为 null（如发送给外部人员）
	recipient_id                	UUID,
    
	-- 收件人邮箱地址：实际发送的目标地址
	recipient_email             	VARCHAR(255) 			NOT NULL,
    
	-- =====================================================
	-- 发送内容区域（记录实际发送的内容）
	-- =====================================================
	-- 邮件主题：渲染后的最终主题（已替换变量）
	subject                     	TEXT 					NOT NULL,
    
	-- 邮件正文：渲染后的最终正文（已替换变量）
	body                        	TEXT 					NOT NULL,
    
	-- =====================================================
	-- 发送状态区域
	-- =====================================================
	-- 状态流转：
	--   PENDING（等待发送）→ RETRYING（重试中）→ SENT（成功）
	--                                      ↘ FAILED（失败，重试耗尽）
	status                      	VARCHAR(20) 			NOT NULL DEFAULT 'PENDING',
    
	-- 重试次数：当前已重试次数，最大值为 max_retries
	retry_count                 	INTEGER 				DEFAULT 0,
    
	-- 最大重试次数：默认5次，可在代码中配置
	max_retries                 	INTEGER 				DEFAULT 5,
    
	-- =====================================================
	-- 时间戳区域
	-- =====================================================
	-- 创建时间：记录何时发起发送请求
	created_at                  	TIMESTAMP WITH TIME ZONE 	DEFAULT CURRENT_TIMESTAMP,
    
	-- 发送成功时间：status 变为 SENT 时更新
	sent_at                     	TIMESTAMP WITH TIME ZONE,
    
	-- 最终失败时间：status 变为 FAILED 时更新
	failed_at                   	TIMESTAMP WITH TIME ZONE,
    
	-- 最后重试时间：每次重试时更新
	last_retry_at               	TIMESTAMP WITH TIME ZONE,
    
	-- =====================================================
	-- 错误信息区域
	-- =====================================================
	-- 错误详情：记录失败原因，便于排查问题
	error_message               	TEXT,
    
	-- =====================================================
	-- 审计信息区域
	-- =====================================================
	-- 发送人ID：操作人的 user ID（saas_admin 的 ID）
	sent_by                     	UUID,
    
	-- 来源系统：SAAS_OPERATOR（SaaS管理后台）或 SCHOOL_WEBSITE（学校官网）
	source_system               	VARCHAR(50),
    
	-- =====================================================
	-- 机构关联区域
	-- =====================================================
	-- 机构ID：关联到具体学校，用于区分不同机构的邮件记录
	-- NULL 表示未绑定机构（如预校长候选人）
	institution_id               	UUID,

	-- 邮件账号ID：关联到使用的 SMTP account
	-- NULL 表示使用系统默认 SMTP
	email_account_id              	UUID,
	
	-- 业务类型：用于分类邮件（CREDENTIALS/凭证, RESET/重置, NOTIFICATION/通知等）
	business_type                	VARCHAR(50)
);

-- 表和字段注释
COMMENT ON TABLE email.email_log IS '邮件发送日志表，记录所有邮件发送历史。用于审计、故障排查和状态追踪。';
COMMENT ON COLUMN email.email_log.id IS '任务唯一ID（task_id），可用于查询发送状态';
COMMENT ON COLUMN email.email_log.template_code IS '使用的邮件模板代码';
COMMENT ON COLUMN email.email_log.recipient_type IS '收件人类型：PRINCIPAL/TEACHER/STUDENT/PARENT';
COMMENT ON COLUMN email.email_log.recipient_id IS '收件人ID，关联 org.person 表';
COMMENT ON COLUMN email.email_log.recipient_email IS '收件邮箱地址（实际发送目标）';
COMMENT ON COLUMN email.email_log.subject IS '邮件主题（已渲染）';
COMMENT ON COLUMN email.email_log.body IS '邮件正文（已渲染）';
COMMENT ON COLUMN email.email_log.status IS '发送状态：PENDING(等待)/RETRYING(重试中)/SENT(成功)/FAILED(失败)';
COMMENT ON COLUMN email.email_log.retry_count IS '当前重试次数';
COMMENT ON COLUMN email.email_log.max_retries IS '最大重试次数（默认5次）';
COMMENT ON COLUMN email.email_log.created_at IS '发送请求创建时间';
COMMENT ON COLUMN email.email_log.sent_at IS '发送成功时间';
COMMENT ON COLUMN email.email_log.failed_at IS '最终失败时间';
COMMENT ON COLUMN email.email_log.last_retry_at IS '最后一次重试时间';
COMMENT ON COLUMN email.email_log.error_message IS '错误详情（失败时记录）';
COMMENT ON COLUMN email.email_log.sent_by IS '操作人ID（谁触发的发送）';
COMMENT ON COLUMN email.email_log.source_system IS '来源系统：SAAS_OPERATOR/SCHOOL_WEBSITE';
COMMENT ON COLUMN email.email_log.institution_id IS '机构ID，关联 org.education_institution.id，用于区分不同机构的邮件记录';
COMMENT ON COLUMN email.email_log.business_type IS '业务类型：CREDENTIALS(凭证)/RESET(重置)/NOTIFICATION(通知)等';

-- 索引说明：
-- idx_email_log_recipient: 用于查询某人的邮件历史
-- idx_email_log_status: 用于查找待重试的邮件
-- idx_email_log_created_at: 用于按时间范围查询
-- idx_email_log_template: 用于按模板查询
CREATE INDEX idx_email_log_recipient 	ON email.email_log(recipient_id, created_at DESC);
COMMENT ON INDEX email.idx_email_log_recipient IS '按收件人ID和创建时间查询邮件历史';

CREATE INDEX idx_email_log_status 		ON email.email_log(status, retry_count);
COMMENT ON INDEX email.idx_email_log_status IS '按状态查询待重试或失败的邮件';

CREATE INDEX idx_email_log_created_at 	ON email.email_log(created_at);
COMMENT ON INDEX email.idx_email_log_created_at IS '按时间范围查询邮件记录';

CREATE INDEX idx_email_log_template 	ON email.email_log(template_code);
COMMENT ON INDEX email.idx_email_log_template IS '按模板代码查询邮件记录';

-- 【新增】支持多机构隔离的索引
CREATE INDEX idx_email_log_institution 	ON email.email_log(institution_id, recipient_id, template_code);
COMMENT ON INDEX email.idx_email_log_institution IS '按机构ID、收件人ID和模板代码查询（支持多机构隔离）';

-- =====================================================
-- 3. 发送频率限制表 (email_rate_limit)
-- 用途：控制同一收件人的邮件发送频率
-- 说明：
--   - 防止邮件轰炸和滥用
--   - 默认限制：1分钟内同一收件人同一模板只能发送1次
--   - 记录发送次数统计
--   - 联合唯一索引确保每人每模板只有一条记录
-- =====================================================
CREATE TABLE email.email_rate_limit (
	-- 主键：UUID
	id                          	UUID 					PRIMARY KEY DEFAULT gen_random_uuid(),
    
	-- 收件人ID：关联 org.person 表
	-- 作为频率限制的判断依据
	recipient_id                	UUID 					NOT NULL,
    
	-- 模板代码：不同模板有独立的频率限制
	template_code               	VARCHAR(50) 			NOT NULL,
    
	-- 【新增】机构ID：用于区分不同机构的频率限制
	-- NULL 表示全局频率限制，有值表示特定机构的频率限制
	institution_id              	UUID 					NULL,
    
	-- 最后发送时间：判断是否在限制期内
	last_sent_at                	TIMESTAMP WITH TIME ZONE 	NOT NULL,
    
	-- 发送次数统计：记录该收件人该机构该模板的总发送次数
	send_count                  	INTEGER 				DEFAULT 1,
    
	-- 联合唯一约束：确保每人每机构每模板只有一条记录
	UNIQUE(recipient_id, template_code, institution_id)
);

-- 表和字段注释
COMMENT ON TABLE email.email_rate_limit IS '邮件发送频率限制表，防止邮件轰炸。控制同一收件人同一机构同一模板的发送频率（默认1分钟1次），支持多机构隔离。';
COMMENT ON COLUMN email.email_rate_limit.id IS '主键：UUID';
COMMENT ON COLUMN email.email_rate_limit.recipient_id IS '收件人ID，频率限制的判断主体';
COMMENT ON COLUMN email.email_rate_limit.template_code IS '模板代码，不同模板独立计算频率';
COMMENT ON COLUMN email.email_rate_limit.institution_id IS '机构ID，关联 org.education_institution.id，用于区分不同机构的频率限制，NULL表示全局限制';
COMMENT ON COLUMN email.email_rate_limit.last_sent_at IS '最后一次发送时间，用于判断是否在限制期内';
COMMENT ON COLUMN email.email_rate_limit.send_count IS '该收件人该机构该模板的累计发送次数';

-- 索引说明：用于快速查询某人的频率限制状态
CREATE INDEX idx_rate_limit_lookup 		ON email.email_rate_limit(recipient_id, template_code);
COMMENT ON INDEX email.idx_rate_limit_lookup IS '快速查询某收件人某模板的频率限制状态';

-- 【新增】支持多机构隔离的索引
CREATE INDEX idx_rate_limit_institution 	ON email.email_rate_limit(recipient_id, template_code, institution_id);
COMMENT ON INDEX email.idx_rate_limit_institution IS '快速查询某收件人在特定机构的频率限制状态（支持多机构隔离）';

-- =====================================================
-- 4. 初始化邮件模板数据
-- 用途：插入系统默认模板
-- 说明：
--   - PRINCIPAL_CREDENTIALS: 校长账户凭证邮件
--   - 支持三语：中文、英文、波兰语
--   - 包含变量：username, password, loginUrl, isResend
--   - isResend 变量用于标记是首次发送还是重发
-- =====================================================

-- 校长凭证邮件模板
-- 使用场景：创建校长时自动发送，或手动重发凭证
-- 特殊标记：{{isResend}} 在重发时显示"【重发凭证】"前缀
INSERT INTO email.email_template (
	template_code,
	template_name,
	subject_zh,
	subject_en,
	subject_pl,
	body_zh,
	body_en,
	body_pl,
	variables
) VALUES (
	'PRINCIPAL_CREDENTIALS',
	'校长凭证邮件',
	'{{isResend}}Wonders Academy - 账户已创建请修改密码',
	'{{isResend}}Wonders Academy - Account Created - Please Change Password',
	'{{isResend}}Wonders Academy - Konto Utworzone - Zmień Hasło',
  '您好！

{{isResend}}您的账户凭证如下：
学校名称：{{education_institution.name}}
用户名：{{username}}
密码：{{password}}
登录地址：{{loginUrl}}
⚠️ 出于安全考虑，请在首次登录后立即修改密码。',
  'Hello!

{{isResend}}Your account credentials:
Institution Name: {{education_institution.name}}
Username: {{username}}
Password: {{password}}
Login Address: {{loginUrl}}
⚠️ For security reasons, please change your password immediately after first login.',
  'Cześć!

{{isResend}}Dane dostępowe do konta:
Nazwa szkoły: {{education_institution.name}}
Nazwa użytkownika: {{username}}
Hasło: {{password}}
Adres logowania: {{loginUrl}}
⚠️ Ze względów bezpieczeństwa zmień hasło natychmiast po pierwszym logowaniu.',
  '["username", "password", "loginUrl", "isResend", "education_institution.name"]'
);

-- =====================================================
-- 线索跟进邮件模板
-- 用途：管理员跟进线索时发送
-- 说明：
--   - 三语支持：中文、英文、波兰语
--   - 变量包括：线索信息、机构信息、当前日期
-- =====================================================
INSERT INTO email.email_template (
	template_code,
	template_name,
	subject_zh,
	subject_en,
	subject_pl,
	body_zh,
	body_en,
	body_pl,
	variables
) VALUES (
	'PROSPECT_FOLLOWUP',
	'线索跟进邮件',
	'{{isResend}}Wonders Academy - 关于您对{{sourceCourses}}课程的咨询',
	'{{isResend}}Wonders Academy - About Your {{sourceCourses}} Course Inquiry',
	'{{isResend}}Wonders Academy - Dotyczące Twojego zapytania o kurs {{sourceCourses}}',
	'亲爱的 {{name}}：

感谢您对{{institution.name}}的关注！

我们已经收到您的咨询信息：
- 意向课程：{{sourceCourses}}
- 留言内容：{{message}}

我们的招生团队会尽快与您联系。
{{institution.name}}
联系方式：
- 电话：{{institution.primaryPhone}}{{#if institution.secondaryPhone}} / {{institution.secondaryPhone}}{{/if}}
- 邮箱：{{institution.email}}{{#if institution.email1}} / {{institution.email1}}{{/if}}{{#if institution.email2}} / {{institution.email2}}{{/if}}
{{#if institution.wechatId}}
- 微信：{{institution.wechatId}}
{{/if}}

{{currentDate}}',
	'Dear {{name}}:

Thank you for your interest in {{institution.name}}!

We have received your inquiry:
- Course of Interest: {{sourceCourses}}
- Your Message: {{message}}

Our admissions team will contact you soon.
{{institution.name}}
Contact:
- Phone: {{institution.primaryPhone}}{{#if institution.secondaryPhone}} / {{institution.secondaryPhone}}{{/if}}
- Email: {{institution.email}}{{#if institution.email1}} / {{institution.email1}}{{/if}}{{#if institution.email2}} / {{institution.email2}}{{/if}}
{{#if institution.wechatId}}
- WeChat: {{institution.wechatId}}
{{/if}}

{{currentDate}}',
	'Drogi {{name}}:

Dziękujemy za zainteresowanie {{institution.name}}!

Otrzymaliśmy Twoje zapytanie:
- Kurs zainteresowania: {{sourceCourses}}
- Twoja wiadomość: {{message}}

Nasz zespół rekrutacyjny skontaktuje się z Tobą wkrótce.
{{institution.name}}
Kontakt:
- Telefon: {{institution.primaryPhone}}{{#if institution.secondaryPhone}} / {{institution.secondaryPhone}}{{/if}}
- Email: {{institution.email}}{{#if institution.email1}} / {{institution.email1}}{{/if}}{{#if institution.email2}} / {{institution.email2}}{{/if}}
{{#if institution.wechatId}}
- WeChat: {{institution.wechatId}}
{{/if}}

{{currentDate}}',
	'["name", "email", "phone", "message", "sourceCourses", "institution.name", "institution.primaryPhone", "institution.secondaryPhone", "institution.email", "institution.email1", "institution.email2", "institution.email3", "institution.email4", "institution.wechatId", "currentDate", "isResend"]'
);

-- =====================================================
-- 线索欢迎邮件模板
-- 用途：欢迎新线索
-- =====================================================
INSERT INTO email.email_template (
	template_code,
	template_name,
	subject_zh,
	subject_en,
	subject_pl,
	body_zh,
	body_en,
	body_pl,
	variables
) VALUES (
	'PROSPECT_WELCOME',
	'线索欢迎邮件',
	'{{isResend}}欢迎了解 Wonders Academy - {{sourceCourses}}课程',
	'{{isResend}}Welcome to Wonders Academy - {{sourceCourses}} Courses',
	'{{isResend}}Witamy w Wonders Academy - Kursy {{sourceCourses}}',
	'亲爱的 {{name}}：

欢迎了解{{institution.name}}！

我们很高兴为您提供关于{{sourceCourses}}课程的详细信息。

如有任何问题，请随时联系我们：
{{institution.name}}
电话：{{institution.primaryPhone}}
邮箱：{{institution.email}}

{{currentDate}}',
	'Dear {{name}}:

Welcome to {{institution.name}}!

We are excited to provide you with information about our {{sourceCourses}} courses.

Feel free to contact us:
{{institution.name}}
Phone: {{institution.primaryPhone}}
Email: {{institution.email}}

{{currentDate}}',
	'Drogi {{name}}:

Witamy w {{institution.name}}!

Cieszymy się, że możemy предоставить Вам информацию о naszych kursach {{sourceCourses}}.

Skontaktuj się z nami:
{{institution.name}}
Telefon: {{institution.primaryPhone}}
Email: {{institution.email}}

{{currentDate}}',
	'["name", "email", "phone", "sourceCourses", "institution.name", "institution.primaryPhone", "institution.email", "institution.email1", "currentDate", "isResend"]'
);

-- =====================================================
-- 线索通知邮件模板
-- 用途：向学校通知新线索
-- =====================================================
INSERT INTO email.email_template (
    id, template_code, template_name, subject_zh, body_zh,
    subject_en, body_en, subject_pl, body_pl,
    variables, is_active
) VALUES (
gen_random_uuid(),
'PROSPECT_NOTIFICATION',
'线索通知邮件',
'【新线索】{{institutionName}} 收到新的咨询{{isResend}}',
'==================================================
线索信息
==================================================
姓名     : {{prospectName}}
邮箱     : {{prospectEmail}}
电话     : {{prospectPhone}}
微信     : {{prospectWechat}}
WhatsApp : {{prospectWhatsapp}}
咨询课程 : {{sourceCourses}}
来源页面 : {{sourcePage}}
留言     : {{message}}
提交时间 : {{submitTime}}
==================================================',
'[New Lead] {{institutionName}} received a new inquiry{{isResend}}',
'--------------------------------------------------
Lead Information
--------------------------------------------------
Name     : {{prospectName}}
Email    : {{prospectEmail}}
Phone    : {{prospectPhone}}
WeChat   : {{prospectWechat}}
WhatsApp : {{prospectWhatsapp}}
Course   : {{sourceCourses}}
Source   : {{sourcePage}}
Message  : {{message}}
Time     : {{submitTime}}
--------------------------------------------------',
'[Nowy lead] {{institutionName}} otrzymał nowe zapytanie{{isResend}}',
'--------------------------------------------------
Informacje o leadzie
--------------------------------------------------
Imię     : {{prospectName}}
Email    : {{prospectEmail}}
Telefon  : {{prospectPhone}}
WeChat   : {{prospectWechat}}
WhatsApp : {{prospectWhatsapp}}
Kurs     : {{sourceCourses}}
Źródło   : {{sourcePage}}
Wiadomość: {{message}}
Czas     : {{submitTime}}
--------------------------------------------------',
'["institutionName", "prospectName", "prospectEmail", "prospectPhone", "prospectWechat", "prospectWhatsapp", "sourceCourses", "sourcePage", "message", "submitTime", "isResend"]',
true
);