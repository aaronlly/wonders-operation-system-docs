
-- ==✅=====================================================
-- Purpose: Required PostgreSQL extensions
-- Target: PostgreSQL >= 18
-- =========================================================

CREATE SCHEMA IF NOT EXISTS public;

-- 用于 UUID 生成（gen_random_uuid）
CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;

-- 启用 PostgreSQL 原生能力（冲突检测）
CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;