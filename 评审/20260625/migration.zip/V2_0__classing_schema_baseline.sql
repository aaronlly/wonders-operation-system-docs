-- =========================================================
-- Classing Schema v1.9 变更说明（相对于 v1.8）
-- =========================================================
--
-- 本版本为在 v1.8 基线基础上的一次「受控重构 + 工程收敛」，
-- 不引入新的业务方向，仅对已确认模型进行补全、澄清与工程优化。
--
-- 一、组织与成员模型（org）
-- --------------------------
-- 1. 明确 institution_member 的语义边界：
--    - valid_from / valid_to：成员关系是否存在（主轴）
--    - status：关系存在期间的可用状态
-- 2. 保留 business_identifier 字段，用于学号 / 工号等机构内编号。
-- 3. 明确 institution_role_assignment / campus_role_assignment
--    仅用于管理角色，不承载教学身份。
--
-- 二、资源与教室模型（core）
-- --------------------------
-- 1. 明确 resource 与 room 的职责分离：
--    - resource：教师 / 学生 / 虚拟教室（抽象资源）
--    - room：实体教室（物理空间）
-- 2. 收敛 room 状态枚举，仅保留 active / suspended，
--    避免与合同、教学生命周期混用。
--
-- 三、时间与排课支撑结构（time / execution）
-- --------------------------------------------
-- 1. 明确 time schema 为“排课算法支撑结构”，
--    不作为业务实体对外暴露。
-- 2. 明确 resource_occupancy 为事实型占用记录，
--    不承担强一致性约束职责。
--
-- 四、领域事件与状态日志拆分（system）
-- ------------------------------------
-- 1. domain_event 仅记录业务关键决策事件：
--    - 排课基线生成 / 切换
--    - 教学版本生效
--    - 考勤人工修正
--    - 合同 amendment 生效等
-- 2. 新增 entity_status_log，
--    用于记录低语义、技术级的状态变更历史，
--    与 domain_event 明确分工，不相互替代。
--
-- 五、ID 策略调整（工程层面）
-- ---------------------------
-- 1. 继续保持：
--    - 所有核心业务实体使用 UUID。
-- 2. 在以下“内部高频、过程型、日志型”表中，
--    调整为顺序型 ID（IDENTITY / bigserial）：
--    - system.entity_status_log
--    - execution.resource_occupancy
--    - time.time_pattern
--    - time.time_adjustment
--    - reward.point_transaction
--
-- 六、冻结声明
-- ------------
-- v1.9 为可长期使用的稳定基线版本：
-- - 核心建模原则在 v1.x 范围内不再调整
-- - 后续版本仅允许通过增量迁移扩展功能
-- - 结构性重构延后至未来主版本（v2.x）
--
-- =========================================================


--------------
-- Functions--
--------------
-- =========================================================
-- 把 planned_session + resource_occupancy 事务封装成 PostgreSQL 函数
-- =========================================================

CREATE OR REPLACE FUNCTION academic.create_planned_session_with_occupancy(
    p_schedule_baseline_id uuid,
    p_class_id uuid,
    p_planned_range tstzrange,
    p_teaching_mode enum.academic_teaching_mode_enum
)
    RETURNS uuid
    LANGUAGE plpgsql
AS
$$
DECLARE
    v_planned_session_id uuid;
BEGIN
    -- 1️⃣ 插入 planned_session（可能因时间冲突直接失败）
    INSERT INTO academic.planned_session (id,
                                          schedule_baseline_id,
                                          class_id,
                                          planned_range,
                                          teaching_mode)
    VALUES (gen_random_uuid(),
            p_schedule_baseline_id,
            p_class_id,
            p_planned_range,
            p_teaching_mode)
    RETURNING id INTO v_planned_session_id;

    -- 2️⃣ 教师 / 学生资源占用
    INSERT INTO execution.resource_occupancy (applies_to_type,
                                              applies_to_id,
                                              occupied_range,
                                              source_id,
                                              source_type)
    SELECT 'resource',
           psr.resource_id,
           p_planned_range,
           v_planned_session_id,
           'planned_session'
    FROM academic.planned_session_resource psr
    WHERE psr.planned_session_id = v_planned_session_id;

    -- 3️⃣ 教室（实体 or 虚拟）占用
    INSERT INTO execution.resource_occupancy (applies_to_type,
                                              applies_to_id,
                                              occupied_range,
                                              source_id,
                                              source_type)
    SELECT CASE
               WHEN psl.room_id IS NOT NULL THEN 'room'
               ELSE 'resource'
               END,
           COALESCE(psl.room_id, psl.virtual_room_resource_id),
           p_planned_range,
           v_planned_session_id,
           'planned_session'
    FROM academic.planned_session_location psl
    WHERE psl.planned_session_id = v_planned_session_id;

    -- 4️⃣ 成功
    RETURN v_planned_session_id;

EXCEPTION
    WHEN exclusion_violation THEN
        -- 时间冲突：planned_session 或 resource_occupancy
        RAISE EXCEPTION
            'Scheduling conflict detected for planned_range %',
            p_planned_range
            USING ERRCODE = 'P0001';
END;
$$;

-- =========================================================
-- 把 「切换 baseline」 事务封装成 PostgreSQL 函数
--      对 academic.schedule_baseline 而言：
--          .baseline 是不可变历史
--          .切换 baseline =
--              👉 旧 baseline 失效（is_current = false）
--              👉 新 baseline 生效（is_current = true）
--
--      绝不允许：
--          .同一 class 同时两个 is_current = true
--          .UPDATE 旧 baseline 的 version_seq / 内容
--          .DELETE baseline
--
--      因此：
--          .切换 baseline ≠ UPDATE baseline 内容
--          .切换 baseline = 原子地切换“当前指针”
-- =========================================================
CREATE OR REPLACE FUNCTION academic.switch_schedule_baseline(
    p_class_id uuid,
    p_new_baseline_id uuid,
    p_triggered_by_person_id uuid,
    p_reason text
)
    RETURNS void
    LANGUAGE plpgsql
AS
$$
DECLARE
    v_old_baseline_id uuid;
BEGIN
    /*
     * 1️⃣ 校验：baseline 必须属于该 class
     */
    IF NOT EXISTS (SELECT 1
                   FROM academic.schedule_baseline sb
                   WHERE sb.id = p_new_baseline_id
                     AND sb.class_id = p_class_id) THEN
        RAISE EXCEPTION
            'Baseline % does not belong to class %',
            p_new_baseline_id, p_class_id;
    END IF;

    /*
     * 2️⃣ 锁定当前 baseline（如存在）
     *     FOR UPDATE 是关键：防止并发切换
     */
    SELECT id
    INTO v_old_baseline_id
    FROM academic.schedule_baseline
    WHERE class_id = p_class_id
      AND is_current = true
        FOR UPDATE;

    /*
     * 3️⃣ 如果已经是当前 baseline，直接返回（幂等）
     */
    IF v_old_baseline_id = p_new_baseline_id THEN
        RETURN;
    END IF;

    /*
     * 4️⃣ 取消旧 baseline（如果存在）
     */
    IF v_old_baseline_id IS NOT NULL THEN
        UPDATE academic.schedule_baseline
        SET is_current   = false,
            effective_to = now()
        WHERE id = v_old_baseline_id;
    END IF;

    /*
     * 5️⃣ 设置新 baseline 为当前
     */
    UPDATE academic.schedule_baseline
    SET is_current     = true,
        effective_from = now()
    WHERE id = p_new_baseline_id;

    /*
     * 6️⃣ 记录领域事件（非常重要）
     */
    INSERT INTO system.domain_event (institution_id,
                                     event_type,
                                     event_category,
                                     triggered_by_person_id,
                                     event_reason,
                                     target_type,
                                     target_id,
                                     payload_json)
    SELECT c.institution_id,
           'schedule_baseline_switched',
           'baseline_changing',
           p_triggered_by_person_id,
           p_reason,
           'academic.class',
           p_class_id,
           jsonb_build_object(
                   'old_baseline_id', v_old_baseline_id,
                   'new_baseline_id', p_new_baseline_id
           )
    FROM academic.class c
    WHERE c.id = p_class_id;

END;
$$;

-- =========================================================
-- evaluate_scheduling_proposal
--   Proposal的评分函数（目标函数）
--      输入：scheduling_proposal_id
--      输出：numeric score
--      数据来源：
--          .scheduling_slot
--          .academic.class（preferred_room）
--          .campus_transfer_time（如有）
--          .scoring_profile（权重）
-- =========================================================
CREATE OR REPLACE FUNCTION execution.evaluate_scheduling_proposal(
    p_proposal_id uuid
)
    RETURNS numeric AS
$$
DECLARE
    v_score           numeric := 0;
    v_weights         jsonb;
    v_preferred_room  uuid;
    v_same_room_count int     := 0;
    v_total_slots     int     := 0;
BEGIN
    -- 取 scoring_profile
    SELECT sr.scoring_profile
    INTO v_weights
    FROM execution.scheduling_proposal sp
             JOIN execution.scheduling_run sr
                  ON sr.id = sp.scheduling_run_id
    WHERE sp.id = p_proposal_id;

    -- 班级偏好教室
    SELECT c.preferred_room_id
    INTO v_preferred_room
    FROM academic.class c
             JOIN execution.scheduling_slot ss
                  ON ss.class_id = c.id
    WHERE ss.scheduling_proposal_id = p_proposal_id
    LIMIT 1;

    -- same room bonus
    SELECT COUNT(*) FILTER (WHERE room_id = v_preferred_room),
           COUNT(*)
    INTO v_same_room_count, v_total_slots
    FROM execution.scheduling_slot
    WHERE scheduling_proposal_id = p_proposal_id;

    IF v_total_slots > 0 THEN
        v_score := v_score
            + (v_same_room_count::numeric / v_total_slots)
                       * COALESCE((v_weights -> 'weights' ->> 'same_room_bonus')::numeric, 0);
    END IF;

    -- 其他 penalty / bonus 在此追加
    -- transfer_penalty / late_evening / idle_gap …

    RETURN v_score;
END;
$$ LANGUAGE plpgsql;

-- =========================================================
--  confirm_scheduling_proposal 确认proposal为终稿，事务性完成如下目标：
--  目标（一次事务内完成）
--      .校验 proposal 归属与合法性
--      .锁定 scheduling_run，防止并发确认
--      .标记 proposal 为 selected
--      .更新 scheduling_run → confirmed
--      .生成新的 academic.schedule_baseline（version_seq +1）
--      .将 proposal 下的 slot 物化为 planned_session
--      .同步写入 execution.resource_occupancy
--      .切换旧 baseline 的 is_current = false
-- =========================================================
CREATE OR REPLACE FUNCTION execution.confirm_scheduling_proposal(
    p_proposal_id uuid,
    p_confirmed_by_person_id uuid
)
    RETURNS uuid
    LANGUAGE plpgsql
AS
$$
DECLARE
    v_run_id          uuid;
    v_class_id        uuid;
    v_new_baseline_id uuid;
    v_now             timestamptz := now();
BEGIN
    /*
     * 0️⃣ 锁定 proposal + run（防并发 confirm）
     */
    SELECT sr.id, sr.class_id
    INTO v_run_id, v_class_id
    FROM execution.scheduling_proposal sp
             JOIN execution.scheduling_run sr ON sr.id = sp.scheduling_run_id
    WHERE sp.id = p_proposal_id
        FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Scheduling proposal % not found', p_proposal_id;
    END IF;

    /*
     * 0️⃣.1 幂等保护
     */
    IF EXISTS (SELECT 1
               FROM execution.scheduling_proposal
               WHERE id = p_proposal_id
                 AND is_selected = true) THEN
        RAISE EXCEPTION 'Scheduling proposal % already confirmed', p_proposal_id;
    END IF;

    /*
     * 1️⃣ 校验 run 状态（只允许 paused / running）
     */
    IF (SELECT status
        FROM execution.scheduling_run
        WHERE id = v_run_id)
        NOT IN ('paused', 'running') THEN
        RAISE EXCEPTION
            'Scheduling run % is not in a confirmable state',
            v_run_id;
    END IF;

    /*
     * 2️⃣ 生成新的 schedule_baseline（使用并发安全函数）
     */
    v_new_baseline_id := academic.insert_schedule_baseline_safe(
        p_class_id   := v_class_id,
        p_effective_from := v_now
    );

    /*
     * 3️⃣ 旧 baseline 失效
     */
    UPDATE academic.schedule_baseline
    SET is_current = false
    WHERE class_id = v_class_id
      AND id <> v_new_baseline_id
      AND is_current = true;

    /*
     * 4️⃣ slot → planned_session
     *     只生成“计划事实”，occupancy 由 trigger 统一负责
     */
    WITH slot_to_session AS (
        INSERT INTO academic.planned_session (
                                              id,
                                              class_id,
                                              schedule_baseline_id,
                                              planned_range,
                                              teaching_mode,
                                              created_at,
                                              source_slot_id
            )
            SELECT gen_random_uuid(),
                   v_class_id,
                   v_new_baseline_id,
                   s.slot_range,
                   s.teaching_mode,
                   v_now,
                   s.id
            FROM execution.scheduling_slot s
            WHERE s.scheduling_proposal_id = p_proposal_id
            RETURNING id AS planned_session_id,
                source_slot_id),
         insert_teacher AS (
             INSERT INTO academic.planned_session_resource (
                                                            id,
                                                            planned_session_id,
                                                            resource_id,
                                                            member_role
                 )
                 SELECT gen_random_uuid(),
                        ps.planned_session_id,
                        s.teacher_resource_id,
                        'teacher'
                 FROM execution.scheduling_slot s
                          JOIN slot_to_session ps
                               ON ps.source_slot_id = s.id),
         insert_location AS (
             INSERT INTO academic.planned_session_location (
                                                            id,
                                                            planned_session_id,
                                                            room_id,
                                                            virtual_room_resource_id
                 )
                 SELECT gen_random_uuid(),
                        ps.planned_session_id,
                        s.room_id,
                        NULL
                 FROM execution.scheduling_slot s
                          JOIN slot_to_session ps
                               ON ps.source_slot_id = s.id
                 WHERE s.room_id IS NOT NULL)
    SELECT 1;

    /*
     * 5️⃣ 标记 proposal 为 selected
     */
    UPDATE execution.scheduling_proposal
    SET is_selected = true
    WHERE id = p_proposal_id;

    /*
     * 6️⃣ 更新 scheduling_run → confirmed
     */
    UPDATE execution.scheduling_run
    SET status       = 'confirmed',
        confirmed_at = v_now
    WHERE id = v_run_id
      AND status IN ('paused', 'running');

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'Scheduling run % already confirmed or invalid',
            v_run_id;
    END IF;

    RETURN v_new_baseline_id;
END;
$$;

-- =========================================================
--  create_class_session_with_channels
--      只在 execution 阶段调用
--      输入语义：
--          .一节已经存在的 planned_session
--          .执行层决定：
--          .是否真的上这节课
--          .用什么 delivery channel
--      输出：
--          .新建 execution.class_session
--          .新建对应的 session_delivery_channel
-- =========================================================
CREATE OR REPLACE FUNCTION execution.create_class_session_with_channels(
    p_planned_session_id uuid,
    p_session_type enum.execution_session_type_enum,
    p_default_teaching_mode enum.academic_teaching_mode_enum,
    p_room_id uuid,
    p_virtual_room_resource_id uuid
)
    RETURNS uuid
    LANGUAGE plpgsql
AS
$$
DECLARE
    v_class_session_id uuid;
    v_class_id         uuid;
    v_start            timestamptz;
    v_end              timestamptz;
BEGIN
    /*
     * 1. 读取 planned_session（执行前提）
     */
    SELECT class_id,
           planned_start,
           planned_end
    INTO
        v_class_id,
        v_start,
        v_end
    FROM academic.planned_session
    WHERE id = p_planned_session_id
        FOR UPDATE;

    IF NOT FOUND THEN
        RAISE EXCEPTION
            'Planned session % not found',
            p_planned_session_id;
    END IF;

    /*
     * 2. 创建 class_session（执行事实）
     */
    INSERT INTO execution.class_session (id,
                                         class_id,
                                         planned_session_id,
                                         actual_range,
                                         session_type,
                                         status,
                                         created_at)
    VALUES (gen_random_uuid(),
            v_class_id,
            p_planned_session_id,
            tstzrange(v_start, v_end, '[)'),
            p_session_type,
            'scheduled',
            now())
    RETURNING id INTO v_class_session_id;

    /*
     * 3. 生成 session_delivery_channel
     *    规则：
     *      onsite  → 1 条 onsite（default）
     *      online  → 1 条 online（default）
     *      hybrid  → onsite(default) + online
     */
    IF p_default_teaching_mode = 'onsite' THEN

        INSERT INTO execution.session_delivery_channel (id,
                                                        class_session_id,
                                                        channel_type,
                                                        room_id,
                                                        virtual_room_resource_id,
                                                        is_default,
                                                        created_at)
        VALUES (gen_random_uuid(),
                v_class_session_id,
                'onsite',
                p_room_id,
                NULL,
                true,
                now());

    ELSIF p_default_teaching_mode = 'online' THEN

        INSERT INTO execution.session_delivery_channel (id,
                                                        class_session_id,
                                                        channel_type,
                                                        room_id,
                                                        virtual_room_resource_id,
                                                        is_default,
                                                        created_at)
        VALUES (gen_random_uuid(),
                v_class_session_id,
                'online',
                NULL,
                p_virtual_room_resource_id,
                true,
                now());

    ELSIF p_default_teaching_mode = 'hybrid' THEN

        -- 默认：线下
        INSERT INTO execution.session_delivery_channel (id,
                                                        class_session_id,
                                                        channel_type,
                                                        room_id,
                                                        virtual_room_resource_id,
                                                        is_default,
                                                        created_at)
        VALUES (gen_random_uuid(),
                v_class_session_id,
                'onsite',
                p_room_id,
                NULL,
                true,
                now());

        -- 补充线上
        INSERT INTO execution.session_delivery_channel (id,
                                                        class_session_id,
                                                        channel_type,
                                                        room_id,
                                                        virtual_room_resource_id,
                                                        is_default,
                                                        created_at)
        VALUES (gen_random_uuid(),
                v_class_session_id,
                'online',
                NULL,
                p_virtual_room_resource_id,
                false,
                now());

    ELSE
        RAISE EXCEPTION
            'Unsupported teaching_mode %',
            p_default_teaching_mode;
    END IF;

    RETURN v_class_session_id;
END;
$$;

-- =========================================================
--   0. 动态序列创建工具函数（通用）
-- =========================================================
CREATE OR REPLACE FUNCTION org.ensure_sequence(p_schema_name text, p_seq_name text)
    RETURNS void AS
$$
BEGIN
    EXECUTE format('CREATE SEQUENCE IF NOT EXISTS %I.%I START 1', p_schema_name, p_seq_name);
END;
$$
    LANGUAGE plpgsql;

-- =========================================================
--   0.1 预创建必要的序列
--      EI000000将作为系统虚拟学校存在，
--      以保证第一个真正的学校编号从EI000001开始
-- =========================================================
CREATE SEQUENCE org.institution_code_seq MINVALUE 0 START WITH 0;

-- =========================================================
--   1. 基线排课版本编号生成：FVxxxx（4 位），用于如下场景：
--      场景 1：初次排课排课算法算完之后调用本函数
--          SELECT academic.insert_schedule_baseline_safe(
--              :class_id,
--              now()
--          );
--      场景 2：排课方案变更（插班 / 调整），旧 baseline 仍然存在，新 baseline 作为候选
--
--      ❌ schedule_baseline.version_seq 不应该用 trigger
--      ✅ 必须只允许通过“事务函数”插入
-- =========================================================
CREATE OR REPLACE FUNCTION academic.insert_schedule_baseline_safe(
    p_class_id uuid,
    p_effective_from timestamptz
)
    RETURNS uuid AS
$$
DECLARE
    v_version_seq int;
    v_id          uuid;
BEGIN
    LOOP
        -- 1️⃣ 计算下一个版本号（非锁定读取）
        SELECT COALESCE(MAX(version_seq), 0) + 1
        INTO v_version_seq
        FROM academic.schedule_baseline
        WHERE class_id = p_class_id;

        BEGIN
            -- 2️⃣ 尝试插入
            INSERT INTO academic.schedule_baseline (id, class_id, version_seq, effective_from, is_current)
            VALUES (gen_random_uuid(),
                    p_class_id,
                    v_version_seq,
                    p_effective_from,
                    true)
            RETURNING id INTO v_id;

            -- 3️⃣ 成功则返回
            RETURN v_id;

        EXCEPTION
            WHEN unique_violation THEN
                -- 并发冲突，重试（如在基线版本=Fv0003时，2个用户都同时尝试插入一个基线版本，
                -- 这时能保证只有一个顺利插入Fv0004，另一个会继续尝试，并插入Fv0005）
                -- 但依赖于数据表的唯一索引 UNIQUE (class_id, version_seq)
                NULL;
        END;
    END LOOP;
END;
$$
    LANGUAGE plpgsql;


-- =========================================================
-- ======================= 建表 =============================
-- =========================================================


-- ==✅=====================================================
-- File: 01_org.sql
-- Schema: org
-- Purpose: Institution, Campus, Person, Membership, Roles
-- =========================================================

-- =========================================================
-- Education Institution (Legal Entity)
-- 教培机构法律实体描述
-- v1.9:
--		改为 institution_code + country_code + legal_name唯一
--		增加排课系统内的编号x自增机制：编号，EIxxxxxx，同时约束name长度>=3。
--
-- 【重要】触发器验证逻辑同步说明
-- 本表的约束在触发器 trg_set_institution_code() 中有前置验证
-- 触发器会在生成编号前验证以下约束（避免插入失败时浪费序列号）：
--   - CHECK (char_length(name) >= 3) - name 长度必须 >= 3
--   - NOT NULL 约束 - country_code, legal_name, name 不能为空
-- 
-- 【维护提醒】
-- 如果修改本表的 CHECK 约束或 NOT NULL 约束，必须同步修改触发器：
--   文件位置：本文件 Line ~3950
--   函数名：org.trg_set_institution_code()
-- =========================================================
CREATE TABLE org.education_institution
(
    -- identity
    id                  uuid PRIMARY KEY
                                                           DEFAULT gen_random_uuid(),

    -- business identity
    institution_code    text                      NOT NULL, -- 排课系统内的编号，6位长度：EI000001

    name                text                      NOT NULL, -- 排课系统内的名称
    legal_name          text                      NOT NULL, -- 同：法律意义上的学校机构注册信息

    -- registration
    country_code        text                      NOT NULL, -- 同：法律意义上的学校机构注册信息
    tax_id              text,                               -- 同：法律意义上的学校机构注册信息
    company_register_no text,                               -- 同：法律意义上的学校机构注册信息
    regon               text,                               -- 同：法律意义上的学校机构注册信息
    established_date    date,                               -- 在本排课系统中正式生效的日期
    description    	text,                               

    -- contact information
    primary_phone       text                      NOT NULL,
    secondary_phone     text,
    wechat_id           text,
    email               text,
    email_enrollment    text,
    email_recruitment   text,
    email1              text,
    email2              text,

    -- lifecycle
    status              enum.contract_status_enum NOT NULL,-- 在本排课系统中的状态

    -- audit
    created_at          timestamptz               NOT NULL DEFAULT now(),
    updated_at          timestamptz               NOT NULL DEFAULT now(),

    -- constraints
    CHECK (char_length(name) >= 3),                         -- 学号以name的前三个字符开始，因此name至少要3个字符
    UNIQUE (institution_code, country_code, legal_name)

);


-- =========================================================
--   1. 学校编号生成 EIxxxxxx（6 位）
-- =========================================================
CREATE OR REPLACE FUNCTION org.gen_institution_code(pad_length int DEFAULT 6)
    RETURNS text AS
$$
DECLARE
    seq_value bigint;
BEGIN
    PERFORM * FROM org.ensure_sequence('org', 'institution_code_seq');
    seq_value := nextval('org.institution_code_seq'::regclass);
    RETURN 'EI' || LPAD(seq_value::text, pad_length, '0');
END;
$$
    LANGUAGE plpgsql;


-- =========================================================
--   1.1 set Trigger
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_set_institution_code()
    RETURNS trigger AS
$$
BEGIN
    -- [验证1] 不允许外部指定 institution_code
    IF NEW.institution_code IS NOT NULL THEN
        RAISE EXCEPTION
            'institution_code is system-generated and must not be provided explicitly';
    END IF;

    -- [验证2] 学校名称长度必须 >= 3（对应表定义中的 CHECK 约束）
    -- 注意：如果表定义中的约束有修改，此处必须同步修改
    IF NEW.name IS NULL OR LENGTH(NEW.name) < 3 THEN
        RAISE EXCEPTION 'Validation failed: Institution name must be at least 3 characters. Current length: %', 
            COALESCE(LENGTH(NEW.name)::text, 'NULL');
    END IF;

    -- [验证3] 检查 country_code 不能为空（业务要求）
    IF NEW.country_code IS NULL OR LENGTH(TRIM(NEW.country_code)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: country_code cannot be null or empty';
    END IF;

    -- [验证4] 检查 legal_name 不能为空（业务要求）
    IF NEW.legal_name IS NULL OR LENGTH(TRIM(NEW.legal_name)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: legal_name cannot be null or empty';
    END IF;

    -- 【关键】所有验证通过后，才生成编号，避免浪费序列号
    NEW.institution_code := org.gen_institution_code(6);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_institution_code
    BEFORE INSERT
    ON org.education_institution
    FOR EACH ROW
EXECUTE FUNCTION org.trg_set_institution_code();

-- =========================================================
--   1.2 BEFORE UPDATE：防止修改 institution_code
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_guard_institution_code_immutable()
    RETURNS trigger AS
$$
BEGIN
    IF NEW.institution_code IS DISTINCT FROM OLD.institution_code THEN
        RAISE EXCEPTION
            'institution_code is immutable once assigned';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_institution_code_immutable
    BEFORE UPDATE
    ON org.education_institution
    FOR EACH ROW
EXECUTE FUNCTION org.trg_guard_institution_code_immutable();

-- =========================================================
-- Campus
-- 一个教育机构由多个校区(Campus)组成
-- v1.9:
--		改为 institution_id + campus_code + country_code + city + address_line唯一
--		增加排课系统内学校下属的校区编号y自增机制：编号，EIxxxxxx-CPyyyyyy
-- =========================================================
CREATE TABLE org.campus
(
    -- identity
    id             uuid PRIMARY KEY
                                                      DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid                      NOT NULL
        REFERENCES org.education_institution (id),

    -- business identity
    campus_code    text                      NOT NULL, -- 排课系统内学校下属的编号，EIxxxxxx-CPyyyyyy


    campus_name    text                      NOT NULL, -- 排课系统内的名称
    campus_type    enum.org_campus_type_enum NOT NULL,
    timezone       text                      NOT NULL,

    -- address
    address_line   text                      NOT NULL,
    city           text                      NOT NULL,
    postal_code    text                      NOT NULL,
    country_code   text                      NOT NULL,

    -- lifecycle
    status         enum.contract_status_enum NOT NULL,

    -- audit
    created_at     timestamptz               NOT NULL DEFAULT now(),
    updated_at     timestamptz               NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (institution_id, campus_code, country_code, city, address_line)
);

-- =========================================================
-- Person (Natural Person)
-- v1.9:
--   family_name -> NOT NULL
--   改为 full_name + family_name + country_code + id_document_number唯一
-- =========================================================
CREATE TABLE org.person
(
    -- identity
    id                 uuid PRIMARY KEY
                                                            DEFAULT gen_random_uuid(),

    -- name
    legal_full_name    text                        NOT NULL,
    given_name         text,
    family_name        text,
    preferred_name     text,

    -- personal attributes
    gender             enum.org_person_gender_enum NOT NULL,
    date_of_birth      date                        NOT NULL,
    nationality        text                        NOT NULL,
    religion           text                        NOT NULL,

    -- contact
    primary_phone      text                        NOT NULL,
    wechat_id          text,
    email              text,

    -- address
    address            text                        NOT NULL,
    postal_code        text                        NOT NULL,
    country_code       text                        NOT NULL,

    -- identification
    id_document_type   text                        NOT NULL,
    id_document_number text                        NOT NULL,

    -- audit
    created_at         timestamptz                 NOT NULL DEFAULT now(),
    updated_at         timestamptz                 NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (legal_full_name, country_code, id_document_number)
);

-- =========================================================
-- Institution Member (Student / Teacher / Staff / contractor)
-- 教学相关人员。目前只用到 Student / Teacher
--     valid_from / valid_to  → 关系是否存在（主轴）
--     status  → 关系存在期间的"可用性"
-- v1.9:
--   新增约束：在机构内，每种角色范围内工号/学号不重复
--   增加学号/工号等机构内z自增编号：WACzzzzzz，学校名称前三位+自增编号zzzzzz
--
-- 【重要】触发器验证逻辑同步说明
-- 本表的约束在触发器 trg_set_member_identifier() 中有前置验证
-- 触发器会在生成编号前验证以下约束（避免插入失败时浪费序列号）：
--   - institution_id NOT NULL - 必须指定所属学校
--   - person_id NOT NULL - 必须指定人员
--   - member_type NOT NULL - 成员类型不能为空
--   - status NOT NULL - 状态不能为空
--   - valid_from NOT NULL - 生效日期不能为空
--   - CHECK (valid_to IS NULL OR valid_to >= valid_from) - 失效日期必须晚于生效日期
--   - 外键约束：institution_id 和 person_id 必须存在于对应表中
-- 
-- 【维护提醒】
-- 如果修改本表的约束，必须同步修改触发器：
--   文件位置：本文件 Line ~4204
--   函数名：org.trg_set_member_identifier()
-- =========================================================
CREATE TABLE org.institution_member
(
    -- identity
    id                  uuid PRIMARY KEY
                                                                         DEFAULT gen_random_uuid(),

    -- ownership
    institution_id      uuid                                    NOT NULL
        REFERENCES org.education_institution (id),
    person_id           uuid                                    NOT NULL
        REFERENCES org.person (id),

    -- business identity
    member_type         enum.org_institution_member_type_enum   NOT NULL,
    -- 'student','teacher','staff','contractor'

    business_identifier text                                    NOT NULL, -- 工号/学号： 学校名称前三位+自增编号zzzzzz（由触发器自动生成）
    original_school     text,
    original_school_address text,

    -- lifecycle
    status              enum.org_institution_member_status_enum NOT NULL,
    -- 'draft','active','suspended','completed','cancelled','expired','archived'
    valid_from          date                                    NOT NULL,
    valid_to            date,

    -- audit
    created_at          timestamptz                             NOT NULL DEFAULT now(),
    updated_at          timestamptz                             NOT NULL DEFAULT now(),

    -- constraints
    -- 在机构内，每种角色范围内工号/学号不重复
    UNIQUE (institution_id, member_type, business_identifier),

    CHECK (valid_to IS NULL OR valid_to >= valid_from),

    CHECK (
        status <> 'suspended'
            OR valid_to IS NULL
        )
);

-- =========================================================
-- Institution Role Assignment
-- 学校管理团队/平台团队角色设定. 这张表不含教师和学生
-- v1.9 角色新增法务 'legal'
-- =========================================================
CREATE TABLE org.institution_role_assignment
(
    -- association
    institution_id uuid                           NOT NULL
        REFERENCES org.education_institution (id),
    person_id      uuid                           NOT NULL
        REFERENCES org.person (id),

    -- role
    role_code      enum.org_institution_role_enum NOT NULL,
    --  'principal','academic_director','finance','it_admin','marketing','operations','sales'
    --  teacher/student/guardian/platform roles are NOT stored here

    -- lifecycle
    assigned_from  date                           NOT NULL,
    assigned_to    date,

    -- constraints
    PRIMARY KEY (institution_id, person_id, role_code),
    CHECK (assigned_to IS NULL OR assigned_to >= assigned_from)
);

-- =========================================================
-- Campus Role Assignment
-- 校区相关角色设定：
--   下列两类人员都必须在本校注册
--   类1：分校区管理员，保安，紧急联系人；行政归属到分校区，分校区可能只是本校租的一些场地，因此这几类人员不一定是学校的员工(不一定在上两张表member/role中)
--   类2：分校区接口人，即'interface'，属于本学校平台团队的人（在role表中，role_code=operations)，他来接口分校区
-- v1.9 新增分校区接口人角色'interface'，体现在enum定义中
-- =========================================================
CREATE TABLE org.campus_role_assignment
(
    -- association
    campus_id     uuid                      NOT NULL
        REFERENCES org.campus (id),
    person_id     uuid                      NOT NULL
        REFERENCES org.person (id),

    -- role
    role_code     enum.org_campus_role_enum NOT NULL,
    -- 'campus_manager','safety','emergency','interface'

    -- lifecycle
    assigned_from date                      NOT NULL,
    assigned_to   date,

    -- constraints
    PRIMARY KEY (campus_id, person_id, role_code),
    CHECK (assigned_to IS NULL OR assigned_to >= assigned_from)
);

-- =========================================================
-- Guardian Assignment (Student Guardians)
-- 学生的监护人信息；允许多对多，不能自己监护自己，18岁以下必须指定监护人
-- v1.9 无改动
-- =========================================================
CREATE TABLE org.guardian_assignment
(
    -- association
    student_person_id   uuid                                NOT NULL
        REFERENCES org.person (id),
    guardian_person_id  uuid                                NOT NULL
        REFERENCES org.person (id),

    -- relationship
    relationship_type   enum.org_guardian_relationship_enum NOT NULL,
    is_primary_guardian boolean                             NOT NULL DEFAULT false,

    -- lifecycle
    valid_from          date                                NOT NULL,
    valid_to            date,

    -- constraints
    PRIMARY KEY (student_person_id, guardian_person_id),
    CHECK (valid_to IS NULL OR valid_to >= valid_from)
);

-- ==✅=====================================================
-- File: 02_time.sql
-- Schema: time
-- Purpose: Unified time availability and adjustments
-- Depends on: 01_org.sql, 02_core.sql
--
--      时间字段约定：
--          来源：资源所在的本地时间（前端）
--          写入DB前：统一换算到 UTC
--          表达：date + time
--          不直接参与冲突裁决
-- =========================================================

-- =========================================================
-- Time Baseline (Contract Period / Term)
-- Applies to: resource OR room
-- 每个资源的可用时间段，与合同期限相绑定，在这段时间内可以排课。
-- v1.9 无改动
-- =========================================================
CREATE TABLE time.time_baseline
(
    -- identity
    id              uuid PRIMARY KEY
                                                            DEFAULT gen_random_uuid(),

    -- applies to 关联到资源（和room）
    applies_to_type enum.time_applies_to_type_enum NOT NULL,
    -- 'resource','room'
    applies_to_id   uuid                           NOT NULL,

    -- period
    start_date      date                           NOT NULL,
    end_date        date                           NOT NULL,

    -- audit
    created_at      timestamptz                    NOT NULL DEFAULT now(),

    -- constraints
    CHECK (end_date >= start_date),

    -- 同一个 resource / room，在同一时间只能有一个合同期 baseline
    -- 即：同一 applies_to_type + applies_to_id，baseline 的日期区间 不允许重叠
    CONSTRAINT no_overlap_time_baseline
        EXCLUDE USING gist (
        applies_to_type WITH =,
        applies_to_id WITH =,
        daterange(start_date, end_date, '[]') WITH &&
        )
);

-- =========================================================
-- Time Pattern (Recurring Availability - Atomic)
-- start_time, end_time在应用在写入数据库前统一换算为 UTC
--      在 time_pattern（基础规则层）中，同一个 baseline 下：
--      要么采用“白名单模型”，要么采用“黑名单模型”，二者不能混合。例如：
--          .周一 09:00–12:00 available
--          .周一 10:00–11:00 unavailable   ❌
--          那么10:30到底是可用还是不可用？逻辑上出现问题
-- =========================================================
CREATE TABLE time.time_pattern
(
    -- identity
    id                bigint PRIMARY KEY
        GENERATED ALWAYS AS IDENTITY,

    -- association
    time_baseline_id  uuid                             NOT NULL
        REFERENCES time.time_baseline (id)
            ON DELETE CASCADE,

    -- pattern definition
    pattern_cycle     enum.time_pattern_cycle_enum     NOT NULL,
    -- 'weekly','monthly'
    day_of_week       integer CHECK (day_of_week BETWEEN 1 AND 7),
    day_of_month      integer CHECK (day_of_month BETWEEN 1 AND 31),

    -- time window
    start_time        time                             NOT NULL,
    end_time          time                             NOT NULL,

    -- availability
    availability_type enum.time_availability_type_enum NOT NULL,
    -- 'available','unavailable'

    -- constraints
    CHECK (end_time > start_time),
    CHECK ((end_time - start_time) >= interval '20 minutes'),
    CHECK (
        (pattern_cycle = 'weekly' AND day_of_week IS NOT NULL AND day_of_month IS NULL)
            OR (pattern_cycle = 'monthly' AND day_of_month IS NOT NULL AND day_of_week IS NULL)
        ),

    -- 在同一个 baseline 下，
    -- 同一周期维度（同一周几 / 同一月日）下，
    -- 同一 availability_type下，时间窗口不能重叠。
    --      在 time_pattern（基础规则层）中，同一个 baseline 下：
    --      要么采用“白名单模型”，要么采用“黑名单模型”，二者不能混合。见头部注释。
    CONSTRAINT no_overlap_time_pattern
        EXCLUDE USING gist (
        time_baseline_id WITH =,
        pattern_cycle WITH =,
        day_of_week WITH =,
        day_of_month WITH =,
        tsrange(
                ('1970-01-01'::date + start_time),
                ('1970-01-01'::date + end_time),
                '[)'
        ) WITH &&
        )
);

-- =========================================================
-- Time Adjustment (Temporary / Exceptional Changes)
-- =========================================================
CREATE TABLE time.time_adjustment
(
    -- identity
    id                    bigint PRIMARY KEY
        GENERATED ALWAYS AS IDENTITY,

    -- association
    time_baseline_id      uuid                           NOT NULL
        REFERENCES time.time_baseline (id)
            ON DELETE CASCADE,

    -- adjustment
    adjustment_date       date                           NOT NULL,
    start_time            time                           NOT NULL,
    end_time              time                           NOT NULL,
    adjustment_type       enum.time_adjustment_type_enum NOT NULL,
    -- 'one_time_override',
    -- 'temporary_extension',
    -- 'temporary_reduction',
    -- 'swap_time_slot',
    -- 'emergency_closure',
    -- 'exceptional_opening'

    reason                text                           NOT NULL,
    approved_by_person_id uuid                           NOT NULL
        REFERENCES org.person (id),

    -- audit
    created_at            timestamptz                    NOT NULL DEFAULT now(),

    -- constraints
    CHECK (end_time > start_time),

    -- 同一个 baseline、同一天，
    -- 不允许存在两个时间段重叠的 adjustment，不区分 adjustment_type。例子：
    --      .09:00–10:00  emergency_closure
    --      .09:30–10:30  exceptional_opening
    --      那么09:30–10:30到底是开门还是关门？
    CONSTRAINT no_overlap_time_adjustment
        EXCLUDE USING gist (
        time_baseline_id WITH =,
        adjustment_date WITH =,
        tsrange(
                ('1970-01-01'::date + start_time),
                ('1970-01-01'::date + end_time),
                '[)'
        )
        WITH &&
        )
);

-- ==✅=====================================================
-- File: 03_core.sql
-- Schema: core
-- Purpose: Resource and Room definitions
-- Depends on: 01_org.sql
-- =========================================================

-- =========================================================
-- Resource (Teacher / Student / Virtual Room)
-- 一种资源：老师/学生/虚拟教室
-- =========================================================
CREATE TABLE core.resource
(
    -- identity
    id             uuid PRIMARY KEY
                                                         DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid                         NOT NULL
        REFERENCES org.education_institution (id),

    -- resource definition
    resource_type  enum.core_resource_type_enum NOT NULL,
    -- 'teacher','student','virtual_room'
    person_id      uuid
        REFERENCES org.person (id),
    timezone       text                         NOT NULL,

    -- lifecycle
    status         enum.core_status_enum        NOT NULL,
    -- 'draft',
    -- 'active',
    -- 'suspended',
    -- 'completed',
    -- 'cancelled',
    -- 'expired',
    -- 'archived'

    -- audit
    created_at     timestamptz                  NOT NULL DEFAULT now(),
    updated_at     timestamptz                  NOT NULL DEFAULT now(),

    -- constraints
    CHECK (
        (resource_type IN ('teacher', 'student') AND person_id IS NOT NULL)
            OR (resource_type = 'virtual_room' AND person_id IS NULL)
        )
);

-- =========================================================
-- Room (Physical Classroom)
-- 另一种资源：实体教室。由于有额外的信息（地址），故与上面资源分开定义
-- =========================================================
CREATE TABLE core.room
(
    -- identity
    id              uuid PRIMARY KEY
                                                        DEFAULT gen_random_uuid(),

    -- ownership
    institution_id  uuid                       NOT NULL
        REFERENCES org.education_institution (id),
    campus_id       uuid                       NOT NULL
        REFERENCES org.campus (id),

    -- physical location
    building        text                       NOT NULL,
    floor           text                       NOT NULL,
    room_identifier text                       NOT NULL,
    room_name       text,

    -- capacity
    capacity        integer                    NOT NULL,

    -- lifecycle
    status          enum.core_room_status_enum NOT NULL,

    -- audit
    created_at      timestamptz                NOT NULL DEFAULT now(),
    updated_at      timestamptz                NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (campus_id, building, floor, room_identifier),
    CHECK (capacity > 0)
);


-- ==✅=====================================================
-- File: 04_contract.sql
-- Schema: contract
-- Purpose: Course, CourseVersion, TeachingMaterial, Class, StudyPlan
-- Depends on: 01_org.sql
-- =========================================================

-- =========================================================
-- Contract (Legal Agreement)
-- =========================================================
CREATE TABLE contract.contract
(
    -- identity
    id             uuid PRIMARY KEY
                                                      DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid                      NOT NULL
        REFERENCES org.education_institution (id),

    -- definition
    contract_code  text                      NOT NULL,
    contract_type  enum.contract_type_enum   NOT NULL,

    -- lifecycle
    status         enum.contract_status_enum NOT NULL,
    signed_date    date,

    -- audit
    created_at     timestamptz               NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (institution_id, contract_code)
);

-- =========================================================
-- Contract Amendment (Revisions / Changes)
-- =========================================================
CREATE TABLE contract.contract_amendment
(
    -- identity
    id             uuid PRIMARY KEY
                                                              DEFAULT gen_random_uuid(),

    -- association
    contract_id    uuid                              NOT NULL
        REFERENCES contract.contract (id),

    -- amendment
    amendment_type enum.contract_amendment_type_enum NOT NULL,
    effective_from date                              NOT NULL,
    reason         text                              NOT NULL,

    -- audit
    created_at     timestamptz                       NOT NULL DEFAULT now()
);

-- =========================================================
-- Snapshot (Evidence Snapshot for Amendments)
-- =========================================================
CREATE TABLE contract.snapshot
(
    -- identity
    id            uuid PRIMARY KEY
                                       DEFAULT gen_random_uuid(),

    -- association
    amendment_id  uuid        NOT NULL
        REFERENCES contract.contract_amendment (id),

    -- snapshot
    snapshot_type text        NOT NULL,
    payload_json  jsonb       NOT NULL,
    /* payload_json sample:
        {
          "class_id": "...",
          "original_teacher": "...",
          "planned_total_hours": 48,
          "executed_regular_hours": 42,
          "executed_makeup_hours": 6,
          "unfulfilled_hours": 0,
          "resolution": "fulfilled_with_makeup"
        }
    */

    -- audit
    created_at    timestamptz NOT NULL DEFAULT now()
);

-- ==✅=====================================================
-- File: 04_academic.sql
-- Schema: academic
-- Purpose: Course, CourseVersion, TeachingMaterial, Class, StudyPlan
-- Depends on: 01_org.sql, 02_core.sql
-- =========================================================
-- =========================================================
-- Course (Course Definition)
-- 课程定义
-- =========================================================
CREATE TABLE academic.course
(
    -- identity
    id             uuid PRIMARY KEY
                                                             DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid                             NOT NULL
        REFERENCES org.education_institution (id),

    -- definition
    course_code    text                             NOT NULL,
    course_name    text                             NOT NULL,
    subject_area   text                             NOT NULL,

    -- lifecycle
    status         enum.academic_course_status_enum NOT NULL,

    -- audit
    created_by_id  uuid                             NOT NULL
        REFERENCES org.person (id),
    created_at     timestamptz                      NOT NULL DEFAULT now(),
    updated_at     timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (institution_id, course_code)
);

-- =========================================================
-- Course Version (Minimal Teaching Commitment)
--
--  course
--   └─ course_version   ← 教学目标版本
--         ↑
--         │
--       class           ← 教学组织决策（容器）=> 多个班级可以用同一个教材版本
--         ├─ class_material_version*   ← 用什么教材 => 一个班级可多个教材（主教材，学生用书 + 教师用书，线上平台 + 纸质教材...）
--         ├─ class_member*             ← 哪些人 => 一个班级可多个学生
--         ├─ class_study_plan           ← 教学内容结构
--         │
--         └─ schedule_baseline*         ← 排课方案版本
--              └─ planned_session*      ← 具体节次

-- =========================================================
CREATE TABLE academic.course_version
(
    -- identity
    id                         uuid PRIMARY KEY
                                                                         DEFAULT gen_random_uuid(),

    -- association
    course_id                  uuid                             NOT NULL
        REFERENCES academic.course (id)
            ON DELETE CASCADE,

    -- versioning
    version_code               text                             NOT NULL,
    version_name               text                             NOT NULL,
    description                text                             NOT NULL,
    teaching_mode              enum.academic_teaching_mode_enum NOT NULL,

    -- recommendation
    recommended_total_sessions integer,
    recommended_total_hours    numeric,

    -- effective period
    effective_from             date                             NOT NULL,
    effective_to               date,

    -- audit
    created_by_id              uuid                             NOT NULL
        REFERENCES org.person (id),
    created_at                 timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (course_id, version_code),
    CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

-- =========================================================
-- Teaching Material (Abstract)
-- =========================================================
CREATE TABLE academic.teaching_material
(
    -- identity
    id             uuid PRIMARY KEY
                                                             DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid                             NOT NULL
        REFERENCES org.education_institution (id),

    -- definition
    material_code  text                             NOT NULL,
    material_name  text                             NOT NULL,
    material_type  enum.academic_material_type_enum NOT NULL,

    -- audit
    created_by_id  uuid                             NOT NULL
        REFERENCES org.person (id),
    created_at     timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (institution_id, material_code)
);

-- =========================================================
-- Teaching Material Version
-- =========================================================
CREATE TABLE academic.teaching_material_version
(
    -- identity
    id            uuid PRIMARY KEY
                                       DEFAULT gen_random_uuid(),

    -- association
    material_id   uuid        NOT NULL
        REFERENCES academic.teaching_material (id),

    -- versioning
    version_code  text        NOT NULL,
    version_name  text        NOT NULL,
    description   text        NOT NULL,


    -- audit
    created_by_id uuid        NOT NULL
        REFERENCES org.person (id),
    created_at    timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (material_id, version_code)
);

-- =========================================================
-- Class (Teaching Delivery Unit)
-- 组建班级
-- class（如二年级英语[五班]）组建时要定下课程"英语“（如2025版英语课程），
-- 而2025版”英语“的教材也必须指定（比如是牛津的教材1，或者剑桥英语第二册等），
-- 作为这个班级的选的教材。注：2024版英语教材可能是中国上海或波兰华沙的，
-- 因此多个course（版本）下有多个教材（版本）。组班时，给班级绑定一个课程和教材。
--      class
--       ├─ course_version        ← 教学目标
--       ├─ class_study_plan      ← 教学内容结构（在该目标下）
--       ├─ class_material*       ← 教材事实
--       ├─ class_member*         ← 人员事实
--       └─ schedule_baseline*    ← 时间方案
-- =========================================================
CREATE TABLE academic.class
(
    -- identity
    id                uuid PRIMARY KEY
                                                               DEFAULT gen_random_uuid(),

    -- ownership
    institution_id    uuid                            NOT NULL
        REFERENCES org.education_institution (id),

    -- definition
    course_version_id uuid                            NOT NULL
        REFERENCES academic.course_version (id),
    class_code        text                            NOT NULL,

    -- preferred_room_id:
    -- soft preference for scheduling algorithm only;
    -- does NOT imply mandatory usage
    --    为 preferred_room_id 的变更记录一个 domain_event
    --      可能场景1：教务建班时手动指定（可选）
    --      可能场景2：班级已存在 → 教务发现“这个班基本固定在 A 教室” → 设置主用教室
    --      可能场景3：排课算法发现：80% planned_session 都在 room A →系统建议将 room A 设为主用教室 → 教务点击确认 → UPDATE class
    preferred_room_id uuid REFERENCES core.room (id),


    -- lifecycle
    status            enum.academic_class_status_enum NOT NULL,
    -- 'draft','active','suspended','completed','cancelled','expired','archived'

    -- audit
    created_at        timestamptz                     NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (institution_id, class_code)
);

-- =========================================================
-- Class_member
-- =========================================================
CREATE TABLE academic.class_member
(
    -- identity
    id                 uuid PRIMARY KEY
                                                                     DEFAULT gen_random_uuid(),

    -- association
    class_id           uuid                                 NOT NULL
        REFERENCES academic.class (id),
    member_resource_id uuid                                 NOT NULL
        REFERENCES core.resource (id),

    -- role
    member_role        enum.academic_class_member_role_enum NOT NULL,
    -- 'student','teacher','assistant'

    -- lifecycle
    joined_at          date,
    left_at            date,

    -- audit
    created_at         timestamptz                          NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (class_id, member_resource_id),
    CHECK (left_at IS NULL OR left_at >= joined_at)
);

/* =========================================================
-- Schedule Baseline (Confirmed Scheduling Snapshot)

   schedule_baseline = “对 planned_session 集合的一次正式确认与冻结”。

    它本身只承担三件事：
        .版本锚点: Fv1 / Fv2 / Fv3严格递增
        .生效区间: 从什么时候开始采用这套方案，effective_from/to
        .历史不可变性: 一旦确认，不再修改，即成为历史事实，
         任何排课变更：必须通过 生成新的 baseline；绝不允许“修改旧 baseline”
    它的唯一作用是回答：“这批 planned_session，是在哪一次决策中被确认的？”
    version_seq 严格递增

   权限层要：
    REVOKE UPDATE (is_current) ON academic.schedule_baseline FROM app_user;
   应用层只暴露一个 API
    POST /classes/{id}/schedule-baselines/{baselineId}/activate
   后端 只调用：
        SELECT academic.switch_schedule_baseline(...);
-- ========================================================= */
CREATE TABLE academic.schedule_baseline
(
    id                  uuid PRIMARY KEY
                                             DEFAULT gen_random_uuid(),

    -- ownership
    class_id            uuid        NOT NULL
        REFERENCES academic.class (id),

    -- versioning X
    -- 仅表示时间顺序（应用层呈现Fv000X），不携带任何业务语义
    -- DDL 里只定义 version_seq integer NOT NULL
    -- 所有插入都必须走 insert_schedule_baseline_safe()，详见头部注释。
    version_seq         integer     NOT NULL,

    -- lifecycle
    effective_from      timestamptz NOT NULL,
    effective_to        timestamptz,

    -- causation
    created_by_event_id uuid,
    -- 允许为空（例如初始建班）

    is_current          boolean     NOT NULL DEFAULT false,

    -- audit
    created_at          timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (class_id, version_seq)
);
-- 约束：每个class只能有一个true的当前基线
CREATE UNIQUE INDEX uq_schedule_baseline_current
    ON academic.schedule_baseline (class_id)
    WHERE is_current = true;

-- =========================================================
-- Planned Session (Scheduled but Not Yet Executed)
--  某学生请假的话，不能修改本表，本表表示计划的内容，而不是考勤的内容
--      本表含某个班级每次（每条记录）“连续、不可再拆分的教学时间占用计划”。
--      它不等同于“一节课”，而是排课算法认定的最小连续时间单元。
--            -老师 1 条
--            -每个学生 1 条
--            -教室 1 条
--            -每个时段一条（比如未来半年每周五10:00-12:00，那么每周五都有一条记录）
--            -是将基于time.xxxx表格的规律性的时间可用度枚举地展开到每月/每天/每时段
--      完全支持： 同一个班级，在不同时段，使用不同教室
-- =========================================================
CREATE TABLE academic.planned_session
(
    id                   uuid PRIMARY KEY
                                                                   DEFAULT gen_random_uuid(),

    -- ownership
    class_id             uuid                             NOT NULL
        REFERENCES academic.class (id),

    -- baseline binding
    schedule_baseline_id uuid                             NOT NULL
        REFERENCES academic.schedule_baseline (id)
            ON DELETE CASCADE,

    -- planned timing (UTC absolute time)
    planned_range        tstzrange                        NOT NULL,
    -- 为了便于查询
    planned_start        timestamptz GENERATED ALWAYS AS (lower(planned_range)) STORED,
    planned_end          timestamptz GENERATED ALWAYS AS (upper(planned_range)) STORED,

    -- teaching
    teaching_mode        enum.academic_teaching_mode_enum NOT NULL,
    -- 'onsite','online','hybrid'

    -- audit
    source_slot_id       uuid,
    created_at           timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    CHECK (upper(planned_range) > lower(planned_range)),

    -- 同一班级 + 同一排课基线下，不允许时间重叠
    CONSTRAINT no_overlap_planned_session
        EXCLUDE USING gist (
        class_id WITH =,
        schedule_baseline_id WITH =,
        planned_range WITH &&
        )
);

CREATE UNIQUE INDEX uq_planned_session_source_slot
    ON academic.planned_session (source_slot_id)
    WHERE source_slot_id IS NOT NULL;

CREATE INDEX idx_planned_session_range
    ON academic.planned_session
        USING gist (planned_range);

-- =========================================================
-- Planned Session Resource Assignment
-- =========================================================
CREATE TABLE academic.planned_session_resource
(
    id                 uuid PRIMARY KEY
        DEFAULT gen_random_uuid(),

    -- association
    planned_session_id uuid                                 NOT NULL
        REFERENCES academic.planned_session (id)
            ON DELETE CASCADE,
    resource_id        uuid                                 NOT NULL
        REFERENCES core.resource (id),

    -- role
    member_role        enum.academic_class_member_role_enum NOT NULL,

    -- constraints
    UNIQUE (planned_session_id, resource_id)
);

-- =========================================================
-- Planned Session Location
-- =========================================================
CREATE TABLE academic.planned_session_location
(
    id                       uuid PRIMARY KEY
        DEFAULT gen_random_uuid(),

    -- association
    planned_session_id       uuid NOT NULL
        REFERENCES academic.planned_session (id)
            ON DELETE CASCADE,

    -- location
    room_id                  uuid
        REFERENCES core.room (id),
    virtual_room_resource_id uuid
        REFERENCES core.resource (id),

    -- constraints
    CHECK (
        (room_id IS NOT NULL AND virtual_room_resource_id IS NULL)
            OR (room_id IS NULL AND virtual_room_resource_id IS NOT NULL)
        ),
    UNIQUE (planned_session_id)
);

-- =========================================================
-- Planned Session Student Assignment
-- =========================================================
CREATE TABLE academic.planned_session_student
(
    id                  uuid PRIMARY KEY
        DEFAULT gen_random_uuid(),

    -- association
    planned_session_id  uuid NOT NULL
        REFERENCES academic.planned_session (id)
            ON DELETE CASCADE,
    student_resource_id uuid NOT NULL
        REFERENCES core.resource (id),

    -- constraints
    UNIQUE (planned_session_id, student_resource_id)
);

-- =========================================================
-- Class Study Plan (Template) 班级的教学计划，教学内容承诺与知识结构描述对象
--    未来可引入 class_study_plan_version
--      class_study_plan 是班级教学计划，描述的是本班级的课程的知识点，
--      在多个时间学完多批次的知识点（或者在结业时一次性要学完哪些知识点），
--      只为了表述课程的教学内容，而不是课程的排课时间计划。同时，班级里的
--      学生可以继承class_study_plan ，也可以有自己基于class_study_plan
--      的独特的定制版本或进阶版本（由老师或教务指定给具体的某个或某些学生）
--
--  切换 active study_plan：
--      .旧 active → inactive / archived
--      .新 study_plan → active
--    不自动影响：
--      .schedule_baseline
--      .planned_session
--      .execution
--
--   course_version is derived from academic.class.course_version_id
--     (NOT stored on class_study_plan — single source of truth).
--   Relationship: course_version → class → class_study_plan.
--
-- =========================================================
CREATE TABLE academic.class_study_plan
(
    id                     uuid PRIMARY KEY
                                                                         DEFAULT gen_random_uuid(),

    academic_class_id      uuid                                 NOT NULL
        REFERENCES academic.class (id)
            ON DELETE CASCADE,

    -- planning
    planned_total_sessions integer                              NOT NULL,
    planned_total_hours    numeric(6, 2)                        NOT NULL,
    description            text,

    -- lifecycle
    status                 enum.academic_study_plan_status_enum NOT NULL,

    -- audit
    created_at             timestamptz                          NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (academic_class_id)
);
-- 一个 class 在同一时刻只能有一个 active study_plan
CREATE UNIQUE INDEX class_study_plan_one_active_per_class
    ON academic.class_study_plan (academic_class_id)
    WHERE status = 'active';

-- =========================================================
-- Study Plan (Student × Course × Contract Fulfillment Plan)
-- 每个学生都要有一个Study Plan，具体内容体现在description
--    学生级 study_plan 的来源可以是：
--      .手工创建
--      .从 class_study_plan 派生
--    派生时：
--      .复制：
--          ..planned_total_sessions
--          ..planned_total_hours
--      .绑定：
--          ..学生
--          ..合同
--
-- 不建立外键、不建立强引用
-- =========================================================
CREATE TABLE academic.study_plan
(
    -- identity
    id                     uuid PRIMARY KEY
                                                                         DEFAULT gen_random_uuid(),

    -- ownership
    institution_id         uuid                                 NOT NULL
        REFERENCES org.education_institution (id),

    -- association
    student_resource_id    uuid                                 NOT NULL
        REFERENCES core.resource (id),
    course_version_id      uuid                                 NOT NULL
        REFERENCES academic.course_version (id),
    contract_id            uuid                                 NOT NULL
        REFERENCES contract.contract (id),

    -- planning
    planned_total_sessions integer                              NOT NULL,
    planned_total_hours    numeric(6, 2)                        NOT NULL,
    description            text,

    -- lifecycle
    status                 enum.academic_study_plan_status_enum NOT NULL,

    -- audit
    created_at             timestamptz                          NOT NULL DEFAULT now(),

    -- constraints
    CHECK (planned_total_sessions > 0),
    CHECK (planned_total_hours > 0)
);

-- =========================================================
-- Class Session (One Teaching Session)
--      表示一次已被确认的、在某一时间段内实际发生（或被教务确认发生）的教学活动记录。
--
--          逻辑：
--          排课之后，形成planned_session（展开以后每个连续的排课时段<安排在哪天哪个时段>分别写入表格），
--          同时，在resource_occupancy打好标记，以后长时间范围内哪个资源的哪个时段已经被占据，
--          然后，在未来要真正上课了，实际发生的课会记录在 class_session。
--          planned_session是计划，class_session是落地，之间可能发生了一些意外情况，如：
--             .停课/取消/法定假日/教师请假/学生集体缺席
--             .这些情况下：计划存在，但执行未发生
--
--          class_session 只在以下任一条件成立时生成：
--             .教师或教务在系统中“确认已上课”/考勤数据首次写入/教务进行事后补录
--
-- 由于academic.class_session_feedback要是有本表的id做外键
-- 因此必须将本表移至academic.class_session_feedback之前
-- =========================================================
CREATE TABLE execution.class_session
(
    -- identity
    id                 uuid PRIMARY KEY
                                                                   DEFAULT gen_random_uuid(),

    -- association
    class_id           uuid                               NOT NULL
        REFERENCES academic.class (id),
    planned_session_id uuid -- 允许 NULL（例如补课、临时加课）
        REFERENCES academic.planned_session (id),

    -- actual execution time (UTC absolute time)
    actual_range       tstzrange                          NOT NULL,
    -- 为了便于查询
    scheduled_start    timestamptz GENERATED ALWAYS AS (lower(actual_range)) STORED,
    scheduled_end      timestamptz GENERATED ALWAYS AS (upper(actual_range)) STORED,

    -- classification
    session_type       enum.execution_session_type_enum   NOT NULL,
    status             enum.execution_session_status_enum NOT NULL,

    -- audit
    created_at         timestamptz                        NOT NULL DEFAULT now(),

    -- constraints
    CHECK (upper(actual_range) > lower(actual_range))
);

-- =========================================================
-- Class Session Feedback
-- =========================================================
CREATE TABLE academic.class_session_feedback
(
    -- identity
    id                  uuid PRIMARY KEY
                                             DEFAULT gen_random_uuid(),

    -- association
    class_session_id    uuid        NOT NULL
        REFERENCES execution.class_session (id)
            ON DELETE CASCADE,
    student_resource_id uuid        NOT NULL
        REFERENCES core.resource (id),
    teacher_resource_id uuid        NOT NULL
        REFERENCES core.resource (id),

    -- feedback
    feedback_text       text        NOT NULL,
    score               numeric(4, 2),

    -- audit
    created_at          timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (class_session_id, student_resource_id)
);

-- =========================================================
-- Homework Assignment
-- =========================================================
CREATE TABLE academic.homework
(
    -- identity
    id                      uuid PRIMARY KEY
                                                 DEFAULT gen_random_uuid(),

    -- association
    academic_class_id       uuid        NOT NULL
        REFERENCES academic.class (id)
            ON DELETE CASCADE,
    assigned_by_resource_id uuid        NOT NULL
        REFERENCES core.resource (id),

    -- content
    title                   text        NOT NULL,
    description             text        NOT NULL,
    due_at                  timestamptz, -- 前端传的是教师或课堂的时间：上完课教师给出的家庭作业截至时间。
    -- 教师前端输入："dueAtLocal": "2025-03-21T23:59"
    --      后端：获取教师的core.resource.timezone
    --      后端：转为UTC timestamptz，写入academic.homework.due_at
    -- 学生前端显示：
    --      后端：获取该UTC时间，获取学生的core.resource.timezone
    --      后端：转为学生的前端时区时间，返回给学生前端
    -- audit
    created_at              timestamptz NOT NULL DEFAULT now()
);

-- =========================================================
-- Homework Submission
--    文件 / 图片 / 视频 不入表，统一走 media.media_link
-- =========================================================
CREATE TABLE academic.homework_submission
(
    -- identity
    id                      uuid PRIMARY KEY
                                                 DEFAULT gen_random_uuid(),

    -- association
    homework_id             uuid        NOT NULL
        REFERENCES academic.homework (id)
            ON DELETE CASCADE,
    student_resource_id     uuid        NOT NULL
        REFERENCES core.resource (id),

    -- submission
    submission_text         text,
    submitted_at            timestamptz,

    -- review (teacher)
    reviewed_by_resource_id uuid
        REFERENCES core.resource (id),
    review_comment          text,
    score                   numeric(4, 2),

    -- audit
    created_at              timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (homework_id, student_resource_id)
);

-- ==✅=====================================================
-- File: 05_execution.sql
-- Schema: execution
-- Purpose: ClassSession, Attendance, ResourceOccupancy
-- Depends on: 02_core.sql, 04_academic.sql
-- =========================================================

-- =========================================================
-- Campus Transfer Time Matrix
-- 校区之间的最小转场时间（物理不可压缩约束）
-- 用于排课阶段判断跨校区连续课程是否可行
--     .不自动生成对称关系: A → B ≠ B → A（现实中成立）
--     .不涉及老师 / 学生个人能力
--     .是排课算法的硬约束输入
-- =========================================================
CREATE TABLE execution.campus_transfer_time
(
    -- identity
    id                  uuid PRIMARY KEY
                                             DEFAULT gen_random_uuid(),

    -- from / to
    from_campus_id      uuid        NOT NULL
        REFERENCES org.campus (id),
    to_campus_id        uuid        NOT NULL
        REFERENCES org.campus (id),

    -- transfer cost
    general_distance_km bigint      NOT NULL,
    min_transfer_time   interval    NOT NULL,
    -- 例如：'30 minutes'，表示最少需要30分钟

    -- audit
    created_at          timestamptz NOT NULL DEFAULT now(),

    -- invariants
    CHECK (from_campus_id <> to_campus_id),
    CHECK (min_transfer_time > interval '0 minutes'),

    -- constraints
    UNIQUE (from_campus_id, to_campus_id)
);

-- =========================================================
-- Resource Transfer Capability Override
-- 基于campus_transfer_time，针对资源级进行转场能力修正（个体差异 / 特殊授权）
-- =========================================================
CREATE TABLE execution.resource_transfer_capability
(
    -- identity
    id                uuid PRIMARY KEY
                                           DEFAULT gen_random_uuid(),

    -- applies to
    resource_id       uuid        NOT NULL
        REFERENCES core.resource (id),

    -- from / to
    from_campus_id    uuid        NOT NULL
        REFERENCES org.campus (id),
    to_campus_id      uuid        NOT NULL
        REFERENCES org.campus (id),

    -- capability
    min_transfer_time interval    NOT NULL,
    -- 例如：
    --   老师有车：15 minutes
    --   学生行动不便：60 minutes

    -- lifecycle
    valid_from        date        NOT NULL,
    valid_to          date,

    -- audit
    created_at        timestamptz NOT NULL DEFAULT now(),

    -- invariants
    CHECK (min_transfer_time > interval '0 minutes'),
    CHECK (from_campus_id <> to_campus_id),
    CHECK (valid_to IS NULL OR valid_to >= valid_from),

    -- constraints
    UNIQUE (resource_id, from_campus_id, to_campus_id, valid_from)
);

-- =========================================================
-- 排课搜索层-（算法运行层）
-- scheduling_run: 教务触发/做一次排课。在什么时候，用什么参数，为哪个班级跑了一次排课算法
-- 应用层禁止 UPDATE
--      execution.scheduling_run
--          └─ execution.scheduling_proposal
--                 └─ execution.scheduling_slot
--
--      academic.schedule_baseline   ← 仅由“被选中的 proposal”生成
--          └─ academic.planned_session
--
--      字段包含：
--          .为什么排（run_reason）
--          .用什么算法排（algorithm_version）
--          .在什么约束下排（constraint_snapshot）
--          .按什么目标排（scoring_profile）
--
--      对象	                INSERT	UPDATE	            DELETE
--    ----------------------------------------------------------------
--      scheduling_run	    ✅   	⚠️ status only	    ❌
--      scheduling_proposal	✅   	❌（除 is_selected）	❌
--      scheduling_slot	    ✅   	❌	                ❌
--      schedule_baseline	✅   	⚠️ is_current	    ❌
--      planned_session	    ✅   	❌	                ❌
--      resource_occupancy	✅   	⚠️ is_active	    ❌
--      class_session	    ✅   	⚠️ status	        ❌
--      attendance	        ✅   	⚠️ override	        ❌
--    ----------------------------------------------------------------
--                  这张表就是你后端 service 层的“铁律”。
--  状态机
--      draft
--        │
--        │ start_run()
--        ▼
--      running （可插入scheduling_proposal，更新next_search_cursor，is_selected = false）
--        │
--        │ 系统生成 proposal（可分页）
--        │
--        ├──────────────────────────────┐
--        │              │               │
--        │              ▼               │ 教务放弃本次排课
--        │            failed            │                    failed (原因应写入 domain_event)
--        │                              │
--        ▼         教务放弃本次排课        ▼
--      paused ────────────────────>> discarded
--        │
--        │ 教务确认某个 proposal
--        ▼
--      confirmed（执行事务confirm_scheduling_proposal）
-- =========================================================
CREATE TABLE execution.scheduling_run
(
    -- identity
    id                     uuid PRIMARY KEY
                                                                              DEFAULT gen_random_uuid(),

    -- target
    institution_id         uuid                                      NOT NULL
        REFERENCES org.education_institution (id),
    class_id               uuid                                      NOT NULL
        REFERENCES academic.class (id),

    -- reason / intent
    run_reason             enum.execution_scheduling_run_reason_enum NOT NULL,
    -- 'initial'        初排
    -- 'reschedule'     重排（如假期、整体调整）
    -- 'student_change' 插班 / 退班
    -- 'teacher_change' 教师变更
    -- 'manual'         教务手动触发

    -- algorithm
    algorithm_version      text                                      NOT NULL,
    -- 例如: 'v1-greedy', 'v2-beam-3', 'v3-constraint-prop'

    -- frozen inputs
    constraint_snapshot    jsonb                                     NOT NULL,
    scoring_profile        jsonb                                     NOT NULL,

    -- actor
    triggered_by_person_id uuid
        REFERENCES org.person (id),

    -- lifecycle
    status                 enum.execution_scheduling_run_status_enum NOT NULL,
    -- 'draft',            -- 创建中，尚未开始搜索
    -- 'running',          -- 搜索中（可多批次分页产出 proposal）
    -- 'paused',           -- 等待教务反馈（不再生成新 proposal）
    -- 'confirmed',        -- 已确认某一个 proposal
    -- 'discarded',        -- 被放弃（教务重来）
    -- 'failed'            -- 系统判定不可排
    -- 进入后面三种状态后，不允许update除confirmed_at之外的字段！！！！！！！

    -- pagination control，只用于继续搜索，不参与 UI 语义
    next_search_cursor     jsonb,
    -- 用于 TOP-K / beam-search 的 continuation token

    created_at             timestamptz                               NOT NULL DEFAULT now(),
    confirmed_at           timestamptz,

    -- invariants
    CHECK (
        (status <> 'confirmed') OR confirmed_at IS NOT NULL
        )

);

-- =========================================================
-- 排课搜索层-（方案层 / 教务决策层）
-- scheduling_proposal: 系统生成的建议表。一个建议包含一组前后排列的可用的“课时+资源”
--  是一整套“未来 N 周 / N 节课”的安排
--    .教务横向对比 A / B / C
--    .每个 proposal 有一个“整体评分”
--    .只会有 一个 proposal 被采纳，这时，必须同时发生（同一事务，见confirm_scheduling_proposal）：
--          ..proposal.is_selected = true
--          ..scheduling_run.status = completed
--          ..新建 schedule_baseline（version_seq +1）
--          ..旧 baseline is_current = false
-- =========================================================
CREATE TABLE execution.scheduling_proposal
(
    -- identity
    id                uuid PRIMARY KEY
                                              DEFAULT gen_random_uuid(),

    scheduling_run_id uuid           NOT NULL
        REFERENCES execution.scheduling_run (id)
            ON DELETE CASCADE,

    -- ordering
    proposal_rank     integer        NOT NULL,
    -- 在本 run 内的排序（1,2,3,...）一旦写入，永不变

    -- quality
    total_score       numeric(10, 4) NOT NULL,

    -- deduplication
    structure_hash    text           NOT NULL,

    -- optional quality breakdown (for UI / debug)
    quality_snapshot  jsonb,
    -- 示例:
    -- {
    --   "same_room_ratio": 0.92,
    --   "teacher_transfer_minutes": 35,
    --   "late_evening_sessions": 1
    -- }

    -- decision
    is_selected       boolean        NOT NULL DEFAULT false,

    created_at        timestamptz    NOT NULL DEFAULT now(),

    CONSTRAINT uq_proposal_index
        UNIQUE (scheduling_run_id, proposal_rank),

    CONSTRAINT uq_proposal_structure
        UNIQUE (scheduling_run_id, structure_hash)
);
-- 约束：业务规则是每个 scheduling_run_id 只能有一个 is_selected = true
CREATE UNIQUE INDEX uq_one_selected_proposal
    ON execution.scheduling_proposal (scheduling_run_id)
    WHERE is_selected = true;

-- =========================================================
-- 排课搜索层
-- scheduling_slot: 每个课时(时间片)配套哪些资源
--      学生：作为班级整体参与，每个学生都要校验时间和占用情况，不需要在这里出现
--      虚拟教室：是 delivery channel 的细节
--      决策核心是（“排课时真正需要决策的资源”，放在字段中）
--          .时间
--          .教师
--          .场地（物理）
-- =========================================================
CREATE TABLE execution.scheduling_slot
(
    -- identity
    id                     uuid PRIMARY KEY
                                                                     DEFAULT gen_random_uuid(),

    scheduling_proposal_id uuid                             NOT NULL
        REFERENCES execution.scheduling_proposal (id)
            ON DELETE CASCADE,

    class_id               uuid                             NOT NULL
        REFERENCES academic.class (id),

    -- proposal里的第 x 节课。只靠时间 range 是不够的，因为：
    -- proposal A / B 时间不同，但结构上可能是“同一节课”
    lesson_index           integer                          NOT NULL,

    -- planned time (UTC)
    slot_range             tstzrange                        NOT NULL,

    -- teaching
    teaching_mode          enum.academic_teaching_mode_enum NOT NULL,

    -- core decisions
    teacher_resource_id    uuid                             NOT NULL
        REFERENCES core.resource (id),

    room_id                uuid
        REFERENCES core.room (id),

    created_at             timestamptz                      NOT NULL DEFAULT now(),

    CHECK (upper(slot_range) > lower(slot_range)),
    UNIQUE (scheduling_proposal_id, lesson_index)
);

ALTER TABLE academic.planned_session
    ADD CONSTRAINT fk_planned_session_source_slot
        FOREIGN KEY (source_slot_id)
            REFERENCES execution.scheduling_slot (id);

-- =========================================================
-- Table: execution.session_delivery_channel
-- Purpose: Delivery channels for a class session (onsite / online / hybrid)
-- 这节课，系统允许哪些交付通道存在:
--   .hybrid模式： 每个 class_session → 1..N 条 delivery_channel，每条代表一种交付方式
--   .其他模式： 每个 class_session → 1条 delivery_channel，代表一种交付方式
--
--          class_session : hybrid模式
--          ├─ session_delivery_channel #1
--          │    channel_type = onsite
--          │    room = A-301
--          │
--          └─ session_delivery_channel #2
--               channel_type = online
--               meeting = Zoom-123
-- =========================================================
CREATE TABLE execution.session_delivery_channel
(
    -- identity
    id                       uuid PRIMARY KEY
                                                                       DEFAULT gen_random_uuid(),

    -- association
    class_session_id         uuid                             NOT NULL
        REFERENCES execution.class_session (id)
            ON DELETE CASCADE,

    -- channel
    channel_type             enum.execution_channel_type_enum NOT NULL,
    --'onsite','online'

    -- 本记录是不是默认的type; hybrid 课，但默认全员线下，只有分流者才进 session_channel_participant
    is_default               boolean                          NOT NULL DEFAULT false,

    room_id                  uuid
        REFERENCES core.room (id),
    virtual_room_resource_id uuid
        REFERENCES core.resource (id),

    -- online evidence
    online_meeting_provider  text,
    online_meeting_id        text,
    online_join_url          text,

    -- audit
    created_at               timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (class_session_id, channel_type),
    CHECK (
        (channel_type = 'onsite'
            AND room_id IS NOT NULL
            AND virtual_room_resource_id IS NULL
            AND online_meeting_provider IS NULL
            AND online_meeting_id IS NULL
            AND online_join_url IS NULL)
            OR (channel_type = 'online'
            AND virtual_room_resource_id IS NOT NULL
            AND online_meeting_provider IS NOT NULL
            AND online_meeting_id IS NOT NULL
            AND online_join_url IS NOT NULL
            AND room_id IS NULL)
        )
);

CREATE UNIQUE INDEX session_delivery_channel_class_session_id
    ON execution.session_delivery_channel (class_session_id)
    WHERE is_default = true;

-- =========================================================
-- session_channel_participant 谁，通过哪个 channel 上了这节课
--  场景 1：部分学生线上、部分线下
--  场景 2：老师线下，学生线上（真实存在）
--  场景 3：执行阶段临时切换.Plan/confirm时为线下课，execute时某学生请假改为线上课，
--         只需更新 / 插入一条 session_channel_participant，不需要改排课、不需要改 baseline。
--  Hybrid:
--  一般只生成delivery_channel记录，默认全员按照默认channel（线上或线下）上课，不生成session_channel_participant；
--  execution阶段，只有出现“分流”时才生成本表的记录。
--
--      class_session
--       ├─ session_delivery_channel (onsite, room A)
--       ├─ session_delivery_channel (online, virtual_room X)
--       └─ session_channel_participant
--            ├─ 学生1 → onsite
--            ├─ 学生2 → online
--            └─ 学生3 → online
-- =========================================================
CREATE TABLE execution.session_channel_participant
(
    class_session_id        uuid                             NOT NULL
        REFERENCES execution.class_session (id)
            ON DELETE CASCADE,

    participant_resource_id uuid                             NOT NULL
        REFERENCES core.resource (id),

    channel_type            enum.execution_channel_type_enum NOT NULL,
    -- 'onsite' / 'online'

    -- audit
    assigned_at             timestamptz                      NOT NULL DEFAULT now(),

    -- constraint
    PRIMARY KEY (class_session_id, participant_resource_id),

    --不能把某人分配到一个 不存在的通道
    -- session 删了，participant 自动清
    CONSTRAINT fk_participant_channel_exists
        FOREIGN KEY (class_session_id, channel_type)
            REFERENCES execution.session_delivery_channel (class_session_id, channel_type)
            ON DELETE CASCADE
);
CREATE UNIQUE INDEX resource_student_teacher_only
    ON core.resource (id)
    WHERE resource_type IN ('student', 'teacher');

-- =========================================================
-- Attendance (Actual Participation Record)
-- 某个资源，事实上是怎么参与这节课的，是考勤。
--
-- =========================================================
CREATE TABLE execution.attendance
(
    -- identity
    id                      uuid PRIMARY KEY
                                                                                     DEFAULT gen_random_uuid(),

    -- association
    class_session_id        uuid                                            NOT NULL
        REFERENCES execution.class_session (id),
    participant_resource_id uuid                                            NOT NULL
        REFERENCES core.resource (id),

    -- attendance result
    attendance_status       enum.execution_attendance_status_enum           NOT NULL,
    health_status           enum.execution_health_status_enum,
    attendance_channel_type enum.execution_channel_type_enum                NOT NULL, -- 某个资源通过什么方式上的课

    -- actual timing
    actual_start_time       timestamptz,
    actual_end_time         timestamptz,

    -- recording responsibility
    recorded_by_person_id   uuid
        REFERENCES org.person (id),
    recorded_by_role        enum.execution_attendance_recorded_by_role_enum NOT NULL,
    recording_method        enum.execution_attendance_recording_method_enum NOT NULL,

    -- reason (mandatory for admin override)
    record_reason           text,

    -- audit
    recorded_at             timestamptz                                     NOT NULL DEFAULT now(),

    -- constraints
    CHECK (actual_end_time IS NULL OR actual_end_time >= actual_start_time),
    CHECK (
        recording_method <> 'admin_override'
            OR record_reason IS NOT NULL
        ),
    UNIQUE (class_session_id, participant_resource_id),

    -- attendance 的 channel 必须是 session 已声明的 channel
    CONSTRAINT fk_attendance_channel_exists
        FOREIGN KEY (class_session_id, attendance_channel_type)
            REFERENCES execution.session_delivery_channel (class_session_id, channel_type)
);

-- =========================================================
-- Resource Occupancy (Time Conflict Facts)
-- Applies to: resource OR room
-- 当某资源的某个课（source_session_id）已经排了课，即planned_session已插入记录，就也给他在occupancy表中记录占用。
-- 当在即planned_session计划外发生异常请时，也要记入occupancy表，如补课：
--     情况 A：补课被正式纳入排课体系
--         .教务补录一条 planned_session，再生成 occupancy
--         .这是结构化补课，完全 OK。
--     情况 B：补课只是一个事实，不想污染排课结构
--         .不建 planned_session，直接建：
--             ..class_session（事实）
--             ..resource_occupancy（占用）
--         .这是事实级补课，也完全 OK。
--  👉 这正是为什么 occupancy 必须独立存在。
-- =========================================================
CREATE TABLE execution.resource_occupancy
(
    -- identity
    id              uuid PRIMARY KEY
                                                                  DEFAULT gen_random_uuid(),

    -- applies to
    applies_to_type enum.time_applies_to_type_enum       NOT NULL,
    -- 'resource', 'room'
    applies_to_id   uuid                                 NOT NULL,

    -- occupied time range (UTC absolute time)
    occupied_range  tstzrange                            NOT NULL,
    -- 为了便于查询
    occupied_start  timestamptz GENERATED ALWAYS AS (lower(occupied_range)) STORED,
    occupied_end    timestamptz GENERATED ALWAYS AS (upper(occupied_range)) STORED,

    -- source
    source_id       uuid,
    source_type     enum.execution_occupancy_source_enum NOT NULL,
    -- 'planned_session'    基于排课计划的占用
    -- 'class_session'      基于无预先排课计划的占用（如临时加课，补课，事后补录等）
    -- 'manual_block'       场景：如非课程执行、非自动排课流程产生的、由人工（教务/管理员）明确声明的“资源不可用时间段”
    --                           老师学生临时请假，突发状况、教室被临时占用，系统外原因：不是某一节课，也不是某个班级......
    --                           是“非教学占用”的专用入口


    -- lifecycle
    is_active       boolean                              NOT NULL DEFAULT true,
    -- 如果临时取消了（对应于一个planned_session），则is_active = false
    -- 临时封闭一段时间：新增一条 manual_block occupancy（is_active = true）

    -- audit
    created_at      timestamptz                          NOT NULL DEFAULT now(),

    -- invariants
    CHECK (upper(occupied_range) > lower(occupied_range)),

    -- 同一对象，在同一时间轴上，不允许物理重叠
    CONSTRAINT no_overlap_resource_occupancy
        EXCLUDE USING gist (
        applies_to_type WITH =,
        applies_to_id WITH =,
        occupied_range WITH &&
        )
);

-- ==✅=====================================================
-- File: 06_system.sql
-- Schema: system
-- 它是：
--      谁
--      在什么角色下
--      因为什么业务意图
--      触发了什么领域变化
--      在什么时候
-- 必须记录的事件
--      排课基线生成 / 切换
--      教学内容版本生效
--      学习计划创建 / 归档
--      教师请假 → 补课裁决
--      代打卡 / 考勤修正
--      合同 amendment 生效
--      服务终止 / 恢复
--
--      | event_type                   | 说明       |
--      | ---------------------------- | --------  |
--      | schedule_baseline_created    | 生成排课基线   |
--      | schedule_baseline_switched   | 切换当前基线   |
--      | teaching_version_activated   | 教学内容版本生效 |
--      | class_study_plan_activated   | 班级学习计划生效 |
--      | study_plan_created           | 学生学习计划创建 |
--      | attendance_admin_override    | 教务代打卡    |
--      | teacher_leave_compensation   | 教师请假补课   |
--      | contract_amendment_effective | 合同修订生效   |
--      | service_terminated           | 授课关系终止   |
--      | service_resumed              | 授课关系恢复   |

-- =========================================================

-- =========================================================
-- Domain Event (Business-Critical Action)
--不允许通过解析 event_type 字符串来判断 category
--
--                  系统影响（event_category）
--                 ┌───────────────────────┐──────────────
--                 │ baseline_changing     │ overlay_only
--  ───────────────┼───────────────────────┼──────────────
--  event_type     │                       │
--  ───────────────┼───────────────────────┼──────────────
--  schedule_      │  ✔                    │
--  baseline_      │                       │
--  created        │                       │
--  ───────────────┼───────────────────────┼──────────────
--  attendance_    │                       │ ✔
--  admin_override │                       │
--  ───────────────┼───────────────────────┼──────────────
--  teaching_      │ ✔                     │
--  version_       │                       │
--  activated      │                       │
--  ───────────────┼───────────────────────┼──────────────
--  teacher_leave_ │ ✔ (若触发新基线)        │ ✔ (仅补课)
--  compensation   │                       │
--
--     也可以考虑把临时取消的原因放在这里，待定。
--
--          event_type = 'SCHEDULE_CANCELLED'
--          event_payload = {
--            source_type: 'planned_session',
--            source_id: '...',
--            reason: 'teacher sick leave'
--          }
-- =========================================================
CREATE TABLE system.domain_event
(
    id                     uuid PRIMARY KEY
                                                             DEFAULT gen_random_uuid(),

    -- context
    institution_id         uuid                     NOT NULL
        REFERENCES org.education_institution (id),

    -- event identity
    event_type             text                     NOT NULL, -- 描述业务事件的具体语义，用于识别发生了什么。
    event_category         enum.event_category_enum NOT NULL, -- 描述事件对系统主线状态的影响等级，用于系统决策。
    -- baseline_changing / overlay_only

    -- actor
    triggered_by_person_id uuid                     NOT NULL
        REFERENCES org.person (id),
    triggered_by_role      enum.org_institution_role_enum,

    -- intent
    event_reason           text                     NOT NULL,

    -- target (what this event is about)
    target_type            text                     NOT NULL,
    target_id              uuid                     NOT NULL,

    -- payload (business snapshot / decision detail)
    payload_json           jsonb                    NOT NULL,

    -- audit
    created_at             timestamptz              NOT NULL DEFAULT now()
);

CREATE INDEX idx_domain_event_created_at
    ON system.domain_event (created_at DESC);

CREATE INDEX idx_domain_event_category
    ON system.domain_event (event_category);

CREATE INDEX idx_domain_event_target
    ON system.domain_event (target_type, target_id);

CREATE INDEX idx_domain_event_actor
    ON system.domain_event (triggered_by_person_id);

-- =========================================================
-- Entity Status Change Log
-- 技术级状态变更日志（不可变、全量、低语义）
-- =========================================================
CREATE TABLE system.entity_status_log
(
    -- identity
    id                    bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    -- target
    entity_type           text        NOT NULL, -- e.g. 'room', 'campus', 'institution_member'
    entity_id             uuid        NOT NULL,

    -- status change
    from_status           text,                 -- nullable for initial state
    to_status             text        NOT NULL,

    -- actor
    operated_by_person_id uuid
        REFERENCES org.person (id),
    operated_by_role      enum.org_institution_role_enum,

    -- context
    reason                text,
    source                text,                 -- api / admin / system / migration

    -- audit
    created_at            timestamptz NOT NULL DEFAULT now()
);


-- ==✅=====================================================
-- File: 06_media_biometric.sql
-- Schema: media, biometric
-- Purpose: Amendments, Snapshots, Media Evidence
-- Depends on: 01_org.sql, 04_academic.sql, 05_execution.sql
-- =========================================================

-- =========================================================
-- Media Object (Stored Evidence)
-- =========================================================
CREATE TABLE media.media_object
(
    -- identity
    id             uuid PRIMARY KEY
                                        DEFAULT gen_random_uuid(),

    -- ownership
    institution_id uuid        NOT NULL
        REFERENCES org.education_institution (id),

    -- media
    media_type     text        NOT NULL,
    storage_path   text        NOT NULL,
    checksum       text,

    -- audit
    created_at     timestamptz NOT NULL DEFAULT now()
);

-- =========================================================
-- Media Link (Attach Media to Any Domain Object)
-- =========================================================
CREATE TABLE media.media_link
(
    -- identity
    id              uuid PRIMARY KEY
                                                              DEFAULT gen_random_uuid(),

    -- association
    media_object_id uuid                             NOT NULL
        REFERENCES media.media_object (id)
            ON DELETE CASCADE,
    target_id       uuid                             NOT NULL,
    target_type     enum.media_link_target_type_enum NOT NULL,

    -- audit
    created_at      timestamptz                      NOT NULL DEFAULT now()
);

-- =========================================================
-- Biometric Profile (Facial / Biometric Template)
-- =========================================================
CREATE TABLE biometric.biometric_profile
(
    -- identity
    id             uuid PRIMARY KEY
                                        DEFAULT gen_random_uuid(),

    -- association
    person_id      uuid        NOT NULL
        REFERENCES org.person (id),

    -- biometric
    biometric_type text        NOT NULL,

    -- audit
    created_at     timestamptz NOT NULL DEFAULT now()
);


-- ==✅=====================================================
-- File: 08_messaging.sql
-- Schema: messaging
-- Purpose:
-- Depends on:
-- =========================================================

-- =========================================================
-- Broadcast_message, 广播消息内容
--    text：纯文字
--    mixed：文字 + media_link（图片 / 视频）
--    媒体能力通过 media_link 承接，media_link的
--     .target_type = 'broadcast_message'
--     .target_id   = messaging.broadcast_message.id
-- =========================================================
CREATE TABLE messaging.broadcast_message
(
    -- identity
    id                   uuid PRIMARY KEY
                                                                             DEFAULT gen_random_uuid(),

    -- ownership
    institution_id       uuid                                       NOT NULL
        REFERENCES org.education_institution (id),

    -- content
    title                text                                       NOT NULL,
    body_text            text                                       NOT NULL, -- 仅承载文本内容

    content_type         enum.messaging_broadcast_content_type_enum NOT NULL,

    -- lifecycle
    status               enum.messaging_broadcast_status_enum       NOT NULL,
    published_at         timestamptz,
    withdrawn_at         timestamptz,

    -- audit
    created_by_person_id uuid                                       NOT NULL
        REFERENCES org.person (id),
    created_at           timestamptz                                NOT NULL DEFAULT now(),

    -- constraints
    CHECK (
        status <> 'published'
            OR published_at IS NOT NULL
        )
);

-- =========================================================
-- broadcast_target, 广播消息对象
-- =========================================================
CREATE TABLE messaging.broadcast_target
(
    -- identity
    id                   uuid PRIMARY KEY
                                                                            DEFAULT gen_random_uuid(),

    -- association
    broadcast_message_id uuid                                      NOT NULL
        REFERENCES messaging.broadcast_message (id)
            ON DELETE CASCADE,

    -- targeting
    target_type          enum.messaging_broadcast_target_type_enum NOT NULL,
    target_id            uuid                                      NOT NULL,

    -- audit
    created_at           timestamptz                               NOT NULL DEFAULT now()
);

-- =========================================================
-- broadcast_read, 广播消息读取信息
--      校方：证明“已送达 / 已读”
--      教师 / 学生：证明“未读 / 未收到”
--      法务：时间点证据
-- =========================================================
CREATE TABLE messaging.broadcast_read
(
    broadcast_message_id uuid        NOT NULL
        REFERENCES messaging.broadcast_message (id)
            ON DELETE CASCADE,

    person_id            uuid        NOT NULL
        REFERENCES org.person (id),

    read_at              timestamptz NOT NULL,

    PRIMARY KEY (broadcast_message_id, person_id)
);

-- ==✅=====================================================
-- File: 09_reward.sql
-- Schema: reward积分系统
-- Purpose:
-- Depends on:
-- =========================================================

-- =========================================================
-- point_account, 积分账户表
-- =========================================================
CREATE TABLE reward.point_account
(
    -- identity
    id                uuid PRIMARY KEY
                                                            DEFAULT gen_random_uuid(),

    -- ownership
    account_type      enum.point_account_type_enum NOT NULL,
    owner_resource_id uuid                         NOT NULL
        REFERENCES core.resource (id),

    -- balance
    current_balance   integer                      NOT NULL DEFAULT 0,

    -- audit
    created_at        timestamptz                  NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (account_type, owner_resource_id),
    CHECK (account_type IN ('student', 'teacher'))
);

-- =========================================================
-- point_account, 积分流水表
--	不存“余额快照历史”，余额由流水累计
--	current_balance 仅用于快速读取，可定期校验
-- =========================================================
CREATE TABLE reward.point_transaction
(
    -- identity
    id                  uuid PRIMARY KEY
                                                                  DEFAULT gen_random_uuid(),

    -- association
    point_account_id    uuid                             NOT NULL
        REFERENCES reward.point_account (id),

    -- transaction
    transaction_type    enum.point_transaction_type_enum NOT NULL,
    reason              enum.point_reason_enum           NOT NULL,
    amount              integer                          NOT NULL,
    -- earn: positive
    -- deduct / redeem: negative

    -- context
    related_object_type text,
    related_object_id   uuid,

    -- description
    description         text,

    -- audit
    created_at          timestamptz                      NOT NULL DEFAULT now(),

    -- constraints
    CHECK (amount <> 0)
);


-- =========================================================
-- referral, 推荐关系表（积分来源之一）
-- =========================================================
CREATE TABLE reward.referral
(
    -- identity
    id                   uuid PRIMARY KEY
                                                                 DEFAULT gen_random_uuid(),

    -- association
    referrer_resource_id uuid                           NOT NULL
        REFERENCES core.resource (id),

    -- target
    target_type          enum.referral_target_type_enum NOT NULL,
    target_person_id     uuid,
    target_room_id       uuid,

    -- lifecycle
    status               enum.referral_status_enum      NOT NULL,

    -- audit
    created_at           timestamptz                    NOT NULL DEFAULT now(),

    -- constraints
    CHECK (
        (target_type IN ('student', 'teacher') AND target_person_id IS NOT NULL)
            OR (target_type = 'room' AND target_room_id IS NOT NULL)
        )
);


-- ==✅=====================================================
-- File: 10_report.sql
-- Schema: report
-- Purpose:
-- Depends on:
-- =========================================================

-- =========================================================
-- teacher_attendance_summary, 老师考勤（例子）
--    可扩展其他的报表操作，做成view
-- =========================================================
CREATE VIEW report.teacher_attendance_summary AS
SELECT r.id                                    AS teacher_resource_id,
       date_trunc('month', cs.scheduled_start) AS month,
       COUNT(*)                                AS total_sessions,
       COUNT(*) FILTER (
           WHERE a.attendance_status = 'present'
           )                                   AS present_sessions,
       ROUND(
                       COUNT(*) FILTER (
                   WHERE a.attendance_status = 'present'
                   )::numeric
                   / NULLIF(COUNT(*), 0),
                       4
       )                                       AS attendance_rate
FROM execution.class_session cs
         JOIN execution.attendance a
              ON a.class_session_id = cs.id
         JOIN core.resource r
              ON r.id = a.participant_resource_id
WHERE r.resource_type = 'teacher'
GROUP BY r.id,
         date_trunc('month', cs.scheduled_start);

-- ==✅=====================================================
-- Schema: auth
-- Purpose: Login identity (account), decoupled from person
-- =========================================================

-- =========================================================
-- File: 11_auth.sql
-- user_account (System Login Identity) 用户账户表（登录主体）
--      一个 person 最多一个账号
--      不是每个 person 都必须有账号
--      登录名 不污染 org.person
--      与现有的 enum.contract_status_enum 生命周期完全对齐
-- =========================================================

CREATE TABLE auth.user_account
(
    -- identity
    id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),

    -- association
    institution_id    uuid REFERENCES org.education_institution (id),
    -- NULL when account_scope = 'platform'

    -- account scope
    account_scope     enum.auth_account_scope_enum NOT NULL DEFAULT 'institution',
    -- 'institution' = bound to a specific institution
    -- 'platform'     = platform-level (saas_operator, system_maintainer)

    -- login identity
    login_name        text NOT NULL,
    person_id         uuid NOT NULL
        REFERENCES org.person (id),

    -- account state
    account_status    text NOT NULL,
    -- active / locked / disabled

    -- password state (credential-level)
    must_change_password   boolean NOT NULL DEFAULT false,
    password_status        enum.auth_password_status_enum NOT NULL DEFAULT 'active',

    -- password reset (forgot-password flow)
    password_reset_token   text,
    password_reset_expire  timestamptz,

    -- audit
    created_at        timestamptz NOT NULL DEFAULT now(),
    updated_at        timestamptz NOT NULL DEFAULT now(),

    -- constraints
    CHECK (
        (account_scope = 'institution' AND institution_id IS NOT NULL)
        OR
        (account_scope = 'platform' AND institution_id IS NULL)
    )
);

CREATE UNIQUE INDEX ux_user_account_institution_login
    ON auth.user_account (login_name, institution_id)
    WHERE account_scope = 'institution';

CREATE UNIQUE INDEX ux_user_account_platform_login
    ON auth.user_account (login_name)
    WHERE account_scope = 'platform';

CREATE UNIQUE INDEX ux_user_account_institution_person
    ON auth.user_account (person_id, institution_id)
    WHERE account_scope = 'institution';

CREATE UNIQUE INDEX ux_user_account_platform_person
    ON auth.user_account (person_id)
    WHERE account_scope = 'platform';

-- =========================================================
-- user_password 用户密码表（Phase 1 采用账号密码登录）
-- =========================================================
CREATE TABLE auth.user_password
(
    -- identity
    id              uuid PRIMARY KEY
                                         DEFAULT gen_random_uuid(),

    -- association
    user_account_id uuid        NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,

    -- credential
    password_hash   text        NOT NULL,
    hash_algorithm  text        NOT NULL,
    -- bcrypt / argon2id 现代加密算法已经不需要salt了，在v1.8删除了salt字段

    -- lifecycle
    is_active       boolean     NOT NULL DEFAULT true,
    set_at          timestamptz NOT NULL DEFAULT now(),
    expires_at      timestamptz,

    -- revoking
    revoked_reason  enum.auth_revoked_reason_enum,
    -- CHANGED_BY_USER / RESET_BY_TOKEN / EXPIRED / ADMIN_RESET

    -- audit
    created_at      timestamptz NOT NULL DEFAULT now(),

    -- constraints
    CHECK (expires_at IS NULL OR expires_at > set_at)
);

-- =========================================================
-- user_session 会话表（Web / App）
--	Phase 1 可不写业务逻辑
-- =========================================================
CREATE TABLE auth.user_session
(
    -- identity
    id              uuid PRIMARY KEY
                                         DEFAULT gen_random_uuid(),

    -- association
    user_account_id uuid        NOT NULL
        REFERENCES auth.user_account (id),

    -- session
    session_token   text        NOT NULL,
    expires_at      timestamptz NOT NULL,

    -- audit
    created_at      timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (session_token)
);

-- =========================================================
-- user_workspace_binding 用户可用工作台绑定表（之前的 role_binding语义升级）
--	用户登录后：系统知道有哪些工作台可选
--	权限校验时：校验“是否允许进入该 workspace”
-- =========================================================
CREATE TABLE auth.user_workspace_binding
(
    -- identity
    id                  uuid PRIMARY KEY
                                                           DEFAULT gen_random_uuid(),

    -- association
    user_account_id     uuid                     NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,

    -- workspace
    workspace_type      enum.workspace_type_enum NOT NULL,

    -- context (optional)
    related_resource_id uuid,
    -- teacher  → teacher resource_id
    -- student  → student resource_id
    -- guardian → NULL (linked students resolved via org.guardian_assignment)
    -- academic → NULL
    -- admin    → NULL

    -- audit
    created_at          timestamptz              NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (user_account_id, workspace_type)
);

-- =========================================================
-- platform_role_assignment 平台角色分配表
-- 仅 account_scope = 'platform' 的用户可以分配平台角色
-- =========================================================
CREATE TABLE auth.platform_role_assignment
(
    -- association
    user_account_id uuid                       NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,
    role_code       enum.platform_role_enum    NOT NULL,
    -- 'saas_operator', 'system_maintainer'

    -- lifecycle
    assigned_from   date                       NOT NULL,
    assigned_to     date,

    -- audit
    created_at      timestamptz                NOT NULL DEFAULT now(),
    updated_at      timestamptz                NOT NULL DEFAULT now(),

    -- constraints
    PRIMARY KEY (user_account_id, role_code),
    CHECK (assigned_to IS NULL OR assigned_to >= assigned_from)
);

-- =========================================================
-- user_last_workspace 最近一次工作台
-- 不区分端和角色
-- view_code是前端路由语义
--		login_name →
--		  user_last_workspace ?
--		    ├─ 有 → 进入该 workspace
--		    │        ├─ 查 last_view → 恢复页面
--		    │        └─ 无 → 进入该 workspace 默认 Dashboard
--		    └─ 无 →
--		        ├─ 可用 workspace = 1 → 直接进入
--		        └─ 可用 workspace > 1 → 弹出选择
--		
-- =========================================================
CREATE TABLE auth.user_last_workspace
(
    -- identity
    id              uuid PRIMARY KEY
                                                       DEFAULT gen_random_uuid(),

    -- association
    user_account_id uuid                     NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,

    -- workspace
    workspace_type  enum.workspace_type_enum NOT NULL,

    -- audit
    recorded_at     timestamptz              NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (user_account_id)
);

-- =========================================================
-- user_last_view 最近一次工作台内的最后一次视图表
-- 不区分端和角色
-- view_code是前端路由语义
-- =========================================================
CREATE TABLE auth.user_last_view
(
    -- identity
    id              uuid PRIMARY KEY
                                           DEFAULT gen_random_uuid(),

    -- association
    user_account_id uuid        NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,

    -- view state
    view_code       text        NOT NULL,
    -- e.g. dashboard, academic.class.list, academic.class.detail, execution.today

    view_params     jsonb,
    -- e.g. { "class_id": "...", "date": "2025-03-19" }

    -- audit
    recorded_at     timestamptz NOT NULL DEFAULT now(),

    -- constraints
    UNIQUE (user_account_id)
);

-- =========================================================
-- Refresh Token Table
--   Refresh Token persistence for JWT authentication
--   Enables:
--     - Access token renewal
--     - Login session revocation
--     - Password change / logout / account lock handling
--
-- Notes:
--   - Access Token remains stateless (JWT only)
--   - Refresh Token is stateful and MUST be persisted
-- =========================================================
CREATE TABLE auth.refresh_token
(

    -- identity
    id              uuid PRIMARY KEY
                                         DEFAULT gen_random_uuid(),

    -- association
    user_account_id uuid        NOT NULL
        REFERENCES auth.user_account (id)
            ON DELETE CASCADE,

    -- token value
    token           text        NOT NULL,

    -- enhancement
    user_agent      text,
    ip_hash         text,

    -- lifecycle
    expires_at      timestamptz NOT NULL,
    revoked         boolean     NOT NULL DEFAULT false,

    -- audit
    created_at      timestamptz NOT NULL DEFAULT now(),
    last_used_at    timestamptz,

    -- constraints
    UNIQUE (token)
);
-- ==============================
-- table: refresh_token
-- ==============================
-- table: refresh_token
-- ==============================
-- fast lookup by refresh token string
CREATE INDEX idx_refresh_token_token
    ON auth.refresh_token (token);

-- optional: for account-wide revocation / cleanup
CREATE INDEX idx_refresh_token_user_account
    ON auth.refresh_token (user_account_id);

-- optional: for scheduled cleanup of expired tokens
CREATE INDEX idx_refresh_token_expires_at
    ON auth.refresh_token (expires_at);

-- ==============================
-- table: auth
-- ==============================
-- 一个账号只能有一个当前有效密码
CREATE UNIQUE INDEX ux_user_password_active
    ON auth.user_password (user_account_id)
    WHERE is_active = true;

-- 忘记密码 token 查找
CREATE INDEX ix_user_account_password_reset_token
    ON auth.user_account (password_reset_token);

-- =========================================================
-- Constraints
-- =========================================================
-- ensure expires_at is always in the future at creation time
ALTER TABLE auth.refresh_token
    ADD CONSTRAINT chk_refresh_token_expires_at_future
        CHECK (expires_at > created_at);


--------------
-- Triggers --
--------------
-- =========================================================
-- scheduling_run创建后：
--   ❌ 不允许改 constraint_snapshot / scoring_profile / algorithm_version / run_reason
--   ✅ 只允许 status 变化（running → completed / cancelled）
-- =========================================================
CREATE OR REPLACE FUNCTION execution.trg_scheduling_run_immutable()
    RETURNS trigger AS
$$
BEGIN
    -- 禁止修改关键字段
    IF (
        NEW.class_id <> OLD.class_id OR
        NEW.run_reason <> OLD.run_reason OR
        NEW.algorithm_version <> OLD.algorithm_version OR
        NEW.constraint_snapshot <> OLD.constraint_snapshot OR
        NEW.scoring_profile <> OLD.scoring_profile
        ) THEN
        RAISE EXCEPTION
            'scheduling_run is immutable: only status may be updated';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_scheduling_run_immutable
    BEFORE UPDATE
    ON execution.scheduling_run
    FOR EACH ROW
EXECUTE FUNCTION execution.trg_scheduling_run_immutable();

-- =========================================================
-- scheduling_proposal
--   ❌ 不允许 UPDATE（除了 is_selected）
--   ❌ 不允许 DELETE
-- =========================================================
CREATE OR REPLACE FUNCTION execution.trg_scheduling_proposal_immutable()
    RETURNS trigger AS
$$
BEGIN
    IF (
        NEW.scheduling_run_id <> OLD.scheduling_run_id OR
        NEW.proposal_rank <> OLD.proposal_rank OR
        NEW.total_score <> OLD.total_score OR
        NEW.structure_hash <> OLD.structure_hash OR
        NEW.quality_snapshot IS DISTINCT FROM OLD.quality_snapshot
        ) THEN
        RAISE EXCEPTION
            'scheduling_proposal is immutable except is_selected';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_scheduling_proposal_immutable
    BEFORE UPDATE
    ON execution.scheduling_proposal
    FOR EACH ROW
EXECUTE FUNCTION execution.trg_scheduling_proposal_immutable();

-- 硬规则：只能在 run=running 时选
CREATE OR REPLACE FUNCTION execution.trg_proposal_selectable_only_when_running()
    RETURNS trigger AS
$$
DECLARE
    v_status enum.execution_scheduling_run_status_enum;
BEGIN
    SELECT status
    INTO v_status
    FROM execution.scheduling_run
    WHERE id = NEW.scheduling_run_id;

    IF v_status <> 'running' THEN
        RAISE EXCEPTION
            'cannot select proposal when scheduling_run status is %', v_status;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_proposal_select_guard
    BEFORE UPDATE OF is_selected
    ON execution.scheduling_proposal
    FOR EACH ROW
    WHEN (NEW.is_selected = true)
EXECUTE FUNCTION execution.trg_proposal_selectable_only_when_running();

-- =========================================================
-- scheduling_slot
--   ❌ 不允许 UPDATE（除了 is_selected）
--   ❌ 不允许 DELETE
-- =========================================================
CREATE OR REPLACE FUNCTION execution.trg_scheduling_slot_no_update()
    RETURNS trigger AS
$$
BEGIN
    RAISE EXCEPTION 'scheduling_slot is immutable';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_scheduling_slot_no_update
    BEFORE UPDATE OR DELETE
    ON execution.scheduling_slot
    FOR EACH ROW
EXECUTE FUNCTION execution.trg_scheduling_slot_no_update();

-- =========================================================
-- check_attendance_channel_consistency
--   一致性校验：attendance 里声明的 channel，是否存在于该 session
-- =========================================================
CREATE OR REPLACE FUNCTION execution.check_attendance_channel_exists()
    RETURNS trigger AS
$$
BEGIN
    IF NOT EXISTS (SELECT 1
                   FROM execution.session_delivery_channel sdc
                   WHERE sdc.class_session_id = NEW.class_session_id
                     AND sdc.channel_type = NEW.attendance_channel_type) THEN
        RAISE EXCEPTION
            'Attendance channel % does not exist for class_session %',
            NEW.attendance_channel_type,
            NEW.class_session_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_check_attendance_channel_exists
    BEFORE INSERT OR UPDATE
    ON execution.attendance
    FOR EACH ROW
EXECUTE FUNCTION execution.check_attendance_channel_exists();

-- =========================================================
-- enforce_single_current_baseline
--   schedule_baseline：保证“永远只有一个 current”
-- =========================================================
CREATE OR REPLACE FUNCTION academic.enforce_single_current_baseline()
    RETURNS trigger AS
$$
BEGIN
    IF NEW.is_current = true THEN
        UPDATE academic.schedule_baseline
        SET is_current = false
        WHERE class_id = NEW.class_id
          AND id <> NEW.id
          AND is_current = true;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_schedule_baseline_single_current
    BEFORE INSERT OR UPDATE OF is_current
    ON academic.schedule_baseline
    FOR EACH ROW
EXECUTE FUNCTION academic.enforce_single_current_baseline();

-- =========================================================
-- guard_schedule_baseline_immutability
--   防止 schedule_baseline 被 UPDATE / DELETE（只允许 is_current 翻转）
--      目的：保证「排课历史不可篡改」，所有调整只能通过 新 baseline。
-- =========================================================
CREATE OR REPLACE FUNCTION academic.guard_schedule_baseline_immutability()
    RETURNS trigger AS
$$
BEGIN
    IF TG_OP = 'DELETE' THEN
        RAISE EXCEPTION 'schedule_baseline is immutable, DELETE forbidden';
    END IF;

    IF TG_OP = 'UPDATE' THEN
        IF NEW.is_current IS DISTINCT FROM OLD.is_current THEN
            RETURN NEW;
        ELSE
            RAISE EXCEPTION 'schedule_baseline is immutable except is_current';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_schedule_baseline_immutability
    BEFORE UPDATE OR DELETE
    ON academic.schedule_baseline
    FOR EACH ROW
EXECUTE FUNCTION academic.guard_schedule_baseline_immutability();

-- =========================================================
-- enforce_single_current_baseline
--   planned_session：防止“幽灵 session”
--      防止出现：
--        planned_session 指向 非 current baseline
--        或 baseline 已 archived / cancelled
-- =========================================================
CREATE OR REPLACE FUNCTION academic.check_planned_session_baseline()
    RETURNS trigger AS
$$
DECLARE
    v_ok boolean;
BEGIN
    SELECT is_current
    INTO v_ok
    FROM academic.schedule_baseline
    WHERE id = NEW.schedule_baseline_id;

    IF v_ok IS DISTINCT FROM true THEN
        RAISE EXCEPTION
            'planned_session must bind to current schedule_baseline %',
            NEW.schedule_baseline_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_planned_session_baseline_valid
    BEFORE INSERT
    ON academic.planned_session
    FOR EACH ROW
EXECUTE FUNCTION academic.check_planned_session_baseline();

-- =========================================================
-- freeze_selected_proposal
--      防止出现：
--        proposal 被确认后仍然被 UPDATE
-- =========================================================
CREATE OR REPLACE FUNCTION execution.freeze_selected_proposal()
    RETURNS trigger AS
$$
BEGIN
    IF OLD.is_selected = true THEN
        RAISE EXCEPTION
            'Selected scheduling_proposal % is immutable',
            OLD.id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_freeze_selected_proposal
    BEFORE UPDATE OR DELETE
    ON execution.scheduling_proposal
    FOR EACH ROW
EXECUTE FUNCTION execution.freeze_selected_proposal();

-- =========================================================
-- check_slot_run_state
--      scheduling_slot：slot 只允许在 proposal 生命周期内存在
--      兜底目的-
--      防止：
--         .scheduling_run 已 confirmed / discarded
--         .仍然插 slot（严重流程错乱）
-- =========================================================
CREATE OR REPLACE FUNCTION execution.check_slot_run_state()
    RETURNS trigger AS
$$
DECLARE
    v_status enum.execution_scheduling_run_status_enum;
BEGIN
    SELECT sr.status
    INTO v_status
    FROM execution.scheduling_proposal sp
             JOIN execution.scheduling_run sr ON sr.id = sp.scheduling_run_id
    WHERE sp.id = NEW.scheduling_proposal_id;

    IF v_status NOT IN ('draft', 'running') THEN
        RAISE EXCEPTION
            'Cannot add slot when scheduling_run status = %',
            v_status;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_slot_run_state_guard
    BEFORE INSERT
    ON execution.scheduling_slot
    FOR EACH ROW
EXECUTE FUNCTION execution.check_slot_run_state();

-- =========================================================
-- guard_planned_session_immutability
--      防止 planned_session 被 UPDATE / DELETE（计划不可被“改”）
--      目的：planned_session 是“计划事实”，一旦确认，只能被 废弃 / 覆盖 / 新基线替代。
-- =========================================================
CREATE OR REPLACE FUNCTION academic.guard_planned_session_immutability()
    RETURNS trigger AS
$$
BEGIN
    IF TG_OP IN ('UPDATE', 'DELETE') THEN
        RAISE EXCEPTION 'planned_session is immutable';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_planned_session_immutability
    BEFORE UPDATE OR DELETE
    ON academic.planned_session
    FOR EACH ROW
EXECUTE FUNCTION academic.guard_planned_session_immutability();

-- =========================================================
-- check_class_session_source
--      class_session：禁止“无来源执行课”悄悄污染系统用
--      兜底目的
--      防止：
--          .教务直接 INSERT class_session
--          .既没有 planned_session，也没有明确说明是 manual / makeup
-- =========================================================
CREATE OR REPLACE FUNCTION execution.check_class_session_source()
    RETURNS trigger AS
$$
BEGIN
    IF NEW.planned_session_id IS NULL
        AND NEW.session_type NOT IN ('makeup', 'manual') THEN
        RAISE EXCEPTION
            'class_session without planned_session must be manual or makeup';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_class_session_source_guard
    BEFORE INSERT
    ON execution.class_session
    FOR EACH ROW
EXECUTE FUNCTION execution.check_class_session_source();

-- =========================================================
-- guard_resource_occupancy
--      防止 resource_occupancy 被 UPDATE（只能新增 / 失效）
--      目的: 占用是事实记录，不能“挪时间”。
-- =========================================================
CREATE OR REPLACE FUNCTION execution.guard_resource_occupancy()
    RETURNS trigger AS
$$
BEGIN
    IF TG_OP = 'UPDATE' THEN
        IF NEW.is_active IS DISTINCT FROM OLD.is_active THEN
            RETURN NEW;
        END IF;
        RAISE EXCEPTION 'resource_occupancy is immutable except is_active';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_resource_occupancy
    BEFORE UPDATE
    ON execution.resource_occupancy
    FOR EACH ROW
EXECUTE FUNCTION execution.guard_resource_occupancy();

-- =========================================================
-- guard_resource_occupancy
--      防止 resource_occupancy 被删除。
-- =========================================================
CREATE OR REPLACE FUNCTION execution.guard_resource_occupancy_delete()
    RETURNS trigger AS
$$
BEGIN
    RAISE EXCEPTION 'resource_occupancy DELETE is forbidden';
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_resource_occupancy_delete
    BEFORE DELETE
    ON execution.resource_occupancy
    FOR EACH ROW
EXECUTE FUNCTION execution.guard_resource_occupancy_delete();

-- =========================================================
-- ensure_occupancy_on_planned_session
--  planned_session 插入后，兜底生成教师占用（若尚不存在）
-- =========================================================
CREATE OR REPLACE FUNCTION execution.ensure_occupancy_on_planned_session()
    RETURNS trigger AS
$$
BEGIN
    INSERT INTO execution.resource_occupancy (applies_to_type,
                                              applies_to_id,
                                              occupied_range,
                                              source_id,
                                              source_type,
                                              is_active,
                                              created_at)
    SELECT 'resource',
           psr.resource_id,
           NEW.planned_range,
           NEW.id,
           'planned_session',
           true,
           now()
    FROM academic.planned_session_resource psr
    WHERE psr.planned_session_id = NEW.id
      AND NOT EXISTS (SELECT 1
                      FROM execution.resource_occupancy ro
                      WHERE ro.source_type = 'planned_session'
                        AND ro.source_id = NEW.id
                        AND ro.applies_to_type = 'resource'
                        AND ro.applies_to_id = psr.resource_id);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ensure_occupancy_on_planned_session
    AFTER INSERT
    ON academic.planned_session
    FOR EACH ROW
EXECUTE FUNCTION execution.ensure_occupancy_on_planned_session();

-- =========================================================
-- check_planned_session_location_consistency
-- =========================================================
CREATE OR REPLACE FUNCTION academic.check_planned_session_location_consistency()
    RETURNS trigger AS
$$
DECLARE
    v_mode enum.academic_teaching_mode_enum;
BEGIN
    SELECT teaching_mode
    INTO v_mode
    FROM academic.planned_session
    WHERE id = NEW.planned_session_id;

    IF v_mode = 'online' AND NEW.room_id IS NOT NULL THEN
        RAISE EXCEPTION
            'online planned_session % cannot have physical room',
            NEW.planned_session_id;
    END IF;

    IF v_mode = 'onsite' AND NEW.room_id IS NULL THEN
        RAISE EXCEPTION
            'onsite planned_session % must have physical room',
            NEW.planned_session_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_planned_session_location_consistency
    BEFORE INSERT
    ON academic.planned_session_location
    FOR EACH ROW
EXECUTE FUNCTION academic.check_planned_session_location_consistency();

-- =========================================================
-- enforce_single_default_delivery_channel
-- =========================================================
CREATE OR REPLACE FUNCTION execution.enforce_default_delivery_channel()
    RETURNS trigger AS
$$
BEGIN
    -- 如果这是第一个 channel，强制设为 default
    IF NOT EXISTS (SELECT 1
                   FROM execution.session_delivery_channel
                   WHERE class_session_id = NEW.class_session_id) THEN
        NEW.is_default := true;
        RETURN NEW;
    END IF;

    -- 如果声明为 default，则清掉其他 default
    IF NEW.is_default = true THEN
        UPDATE execution.session_delivery_channel
        SET is_default = false
        WHERE class_session_id = NEW.class_session_id
          AND id <> NEW.id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_enforce_default_delivery_channel
    BEFORE INSERT OR UPDATE OF is_default
    ON execution.session_delivery_channel
    FOR EACH ROW
EXECUTE FUNCTION execution.enforce_default_delivery_channel();

-- =========================================================
-- check_attendance_channel_participant_consistency
-- =========================================================
CREATE OR REPLACE FUNCTION execution.check_attendance_participant_channel()
    RETURNS trigger AS
$$
BEGIN
    IF EXISTS (SELECT 1
               FROM execution.session_channel_participant scp
               WHERE scp.class_session_id = NEW.class_session_id
                 AND scp.participant_resource_id = NEW.participant_resource_id
                 AND scp.channel_type <> NEW.attendance_channel_type) THEN
        RAISE EXCEPTION
            'attendance channel conflicts with participant channel assignment';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_attendance_participant_channel
    BEFORE INSERT OR UPDATE
    ON execution.attendance
    FOR EACH ROW
EXECUTE FUNCTION execution.check_attendance_participant_channel();

-- =========================================================
-- ensure_occupancy_on_class_session
-- =========================================================
CREATE OR REPLACE FUNCTION execution.ensure_occupancy_on_class_session()
    RETURNS trigger AS
$$
BEGIN
    -- 教师占用（事实）
    INSERT INTO execution.resource_occupancy (applies_to_type,
                                              applies_to_id,
                                              occupied_range,
                                              source_id,
                                              source_type,
                                              is_active,
                                              created_at)
    SELECT 'resource',
           psr.resource_id,
           tstzrange(NEW.scheduled_start, NEW.scheduled_end, '[)'),
           NEW.id,
           'class_session',
           true,
           now()
    FROM academic.planned_session_resource psr
    WHERE NEW.planned_session_id = psr.planned_session_id
      AND NOT EXISTS (SELECT 1
                      FROM execution.resource_occupancy ro
                      WHERE ro.source_type = 'class_session'
                        AND ro.source_id = NEW.id
                        AND ro.applies_to_id = psr.resource_id);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_ensure_occupancy_on_class_session
    AFTER INSERT
    ON execution.class_session
    FOR EACH ROW
EXECUTE FUNCTION execution.ensure_occupancy_on_class_session();

-- =========================================================
-- guard_slot_after_run_confirmed
-- =========================================================
CREATE OR REPLACE FUNCTION execution.guard_slot_after_run_confirmed()
    RETURNS trigger AS
$$
DECLARE
    v_status enum.execution_scheduling_run_status_enum;
BEGIN
    SELECT sr.status
    INTO v_status
    FROM execution.scheduling_proposal sp
             JOIN execution.scheduling_run sr ON sr.id = sp.scheduling_run_id
    WHERE sp.id = NEW.scheduling_proposal_id;

    IF v_status = 'confirmed' THEN
        RAISE EXCEPTION
            'cannot insert scheduling_slot after run is confirmed';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_slot_after_run_confirmed
    BEFORE INSERT
    ON execution.scheduling_slot
    FOR EACH ROW
EXECUTE FUNCTION execution.guard_slot_after_run_confirmed();




-- 【系统级机构记录】用于预校长候选人（尚未绑定真实学校）
INSERT INTO org.education_institution (
    id, name, legal_name, country_code, status, primary_phone,
    tax_id, company_register_no, regon, established_date, created_at
)
VALUES (
    '00000000-0000-0000-0000-000000000000'::uuid,
    'System Virtual Institution',
    'System Virtual Institution',
    'PL',
    'active',
    'N/A',
    'SYSTEM', 'SYSTEM', 'SYSTEM',
    CURRENT_DATE,
    NOW()
);

-- =========================================================
--   2. 校区编号生成 <学校代码>-CPxxxxxx
-- =========================================================
CREATE OR REPLACE FUNCTION org.gen_campus_code(inst_id uuid, pad_length int DEFAULT 6)
    RETURNS text AS
$$
DECLARE
    inst_code text;
    seq_name  text;
    seq_value bigint;
BEGIN
    SELECT institution_code
    INTO inst_code
    FROM org.education_institution
    WHERE id = inst_id;

    IF inst_code IS NULL THEN
        RAISE EXCEPTION 'institution % not found', inst_id;
    END IF;

    seq_name := 'campus_seq_' || substr(md5(inst_id::text), 1, 12); -- 不直接使用inst_id，避免UUID过长被截断，而是HASH一次。
    PERFORM * FROM org.ensure_sequence('org', seq_name);
    seq_value := nextval(('org.' || seq_name)::regclass);
    RETURN inst_code || '-' || 'CP' || LPAD(seq_value::text, pad_length, '0');
END;
$$
    LANGUAGE plpgsql;

-- =========================================================
--   2.1 BEFORE INSERT：生成 campus_code
--   
--   【重要】约束验证逻辑必须与表定义中的约束保持同步
--   当前验证的约束（对应 org.campus 表定义）：
--   - institution_id NOT NULL - 必须指定所属学校
--   - campus_name NOT NULL - 校区名称不能为空
--   - campus_type NOT NULL - 校区类型不能为空
--   - timezone NOT NULL - 时区不能为空
--   - address_line NOT NULL - 地址不能为空
--   - city NOT NULL - 城市不能为空
--   - postal_code NOT NULL - 邮编不能为空
--   - country_code NOT NULL - 国家代码不能为空
--   
--   【验证顺序】
--   1. 检查是否外部指定了 campus_code（禁止）
--   2. 验证所有 NOT NULL 字段
--   3. 验证通过后，才调用 nextval() 生成编号
--   
--   【为什么用 BEFORE INSERT 而不是 AFTER INSERT】
--   - 因为 campus_code 字段定义为 NOT NULL
--   - AFTER INSERT 无法在 INSERT 时设置 NOT NULL 字段的值
--   - 所以采用"先验证后生成"策略，确保验证失败时不消耗序列号
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_set_campus_code()
    RETURNS trigger AS
$$
BEGIN
    -- [验证1] 不允许外部指定 campus_code
    IF NEW.campus_code IS NOT NULL THEN
        RAISE EXCEPTION
            'campus_code is system-generated and must not be provided explicitly';
    END IF;

    -- [验证2] institution_id 不能为空（表定义：NOT NULL）
    IF NEW.institution_id IS NULL THEN
        RAISE EXCEPTION 'Validation failed: institution_id cannot be null';
    END IF;

    -- [验证3] campus_name 不能为空且长度必须 >= 1（表定义：NOT NULL）
    IF NEW.campus_name IS NULL OR LENGTH(TRIM(NEW.campus_name)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: campus_name cannot be null or empty';
    END IF;

    -- [验证4] campus_type 不能为空（表定义：NOT NULL）
    IF NEW.campus_type IS NULL THEN
        RAISE EXCEPTION 'Validation failed: campus_type cannot be null';
    END IF;

    -- [验证5] timezone 不能为空（表定义：NOT NULL）
    IF NEW.timezone IS NULL OR LENGTH(TRIM(NEW.timezone)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: timezone cannot be null or empty';
    END IF;

    -- [验证6] address_line 不能为空（表定义：NOT NULL）
    IF NEW.address_line IS NULL OR LENGTH(TRIM(NEW.address_line)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: address_line cannot be null or empty';
    END IF;

    -- [验证7] city 不能为空（表定义：NOT NULL）
    IF NEW.city IS NULL OR LENGTH(TRIM(NEW.city)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: city cannot be null or empty';
    END IF;

    -- [验证8] postal_code 不能为空（表定义：NOT NULL）
    IF NEW.postal_code IS NULL OR LENGTH(TRIM(NEW.postal_code)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: postal_code cannot be null or empty';
    END IF;

    -- [验证9] country_code 不能为空（表定义：NOT NULL）
    IF NEW.country_code IS NULL OR LENGTH(TRIM(NEW.country_code)) = 0 THEN
        RAISE EXCEPTION 'Validation failed: country_code cannot be null or empty';
    END IF;

    -- 【关键】所有验证通过后，才生成编号，避免浪费序列号
    NEW.campus_code := org.gen_campus_code(NEW.institution_id, 6);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_campus_code
    BEFORE INSERT
    ON org.campus
    FOR EACH ROW
EXECUTE FUNCTION org.trg_set_campus_code();

-- =========================================================
--   2.2 BEFORE UPDATE：防止修改 campus_code
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_guard_campus_code_immutable()
    RETURNS trigger AS
$$
BEGIN
    IF NEW.campus_code IS DISTINCT FROM OLD.campus_code THEN
        RAISE EXCEPTION
            'campus_code is immutable once assigned';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_campus_code_immutable
    BEFORE UPDATE
    ON org.campus
    FOR EACH ROW
EXECUTE FUNCTION org.trg_guard_campus_code_immutable();

-- =========================================================
--   3. 学号生成 <学校名称前三位>zzzzzz（6 位）
-- =========================================================
--   3. 学号生成 <学校名称前三位>zzzzzz（6 位）
-- =========================================================
CREATE OR REPLACE FUNCTION org.gen_member_identifier(inst_id uuid, pad_length int DEFAULT 6)
    RETURNS text AS
$$
DECLARE
    inst_name text;
    prefix    text;
    seq_name  text;
    seq_value bigint;
BEGIN
    SELECT name
    INTO inst_name
    FROM org.education_institution
    WHERE id = inst_id;

    IF inst_name IS NULL THEN
        RAISE EXCEPTION 'institution % not found', inst_id;
    END IF;

    prefix := SUBSTRING(inst_name FROM 1 FOR 3);

    seq_name := 'member_seq_' || inst_id::text;

    -- 确保序列存在
    PERFORM * FROM org.ensure_sequence('org', seq_name);

    -- 使用 nextval 获取下一个值
    seq_value := nextval(('org.' || seq_name)::regclass);

    RETURN prefix || LPAD(seq_value::text, pad_length, '0');
END;
$$
    LANGUAGE plpgsql;

-- =========================================================
--   3.1 BEFORE INSERT：生成 business_identifier
--   
--   【重要】约束验证逻辑必须与表定义中的约束保持同步
--   当前验证的约束（对应 org.institution_member 表定义）：
--   - institution_id NOT NULL - 必须指定所属学校
--   - person_id NOT NULL - 必须指定人员
--   - member_type NOT NULL - 成员类型不能为空
--   - status NOT NULL - 状态不能为空
--   - valid_from NOT NULL - 生效日期不能为空
--   - valid_to IS NULL OR valid_to >= valid_from - 失效日期必须晚于生效日期
--   
--   【验证顺序】
--   1. 验证所有 NOT NULL 字段和 CHECK 约束
--   2. 验证通过后，才调用 nextval() 生成编号
--   
--   【为什么用 BEFORE INSERT 而不是 AFTER INSERT】
--   - 因为 business_identifier 字段定义为 NOT NULL
--   - AFTER INSERT 无法在 INSERT 时设置 NOT NULL 字段的值
--   - 所以采用"先验证后生成"策略，确保验证失败时不消耗序列号
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_set_member_identifier()
    RETURNS trigger AS
$$
BEGIN
    -- [验证1] institution_id 不能为空（表定义：NOT NULL）
    IF NEW.institution_id IS NULL THEN
        RAISE EXCEPTION 'Validation failed: institution_id cannot be null';
    END IF;

    -- [验证2] person_id 不能为空（表定义：NOT NULL）
    IF NEW.person_id IS NULL THEN
        RAISE EXCEPTION 'Validation failed: person_id cannot be null';
    END IF;

    -- [验证3] member_type 不能为空（表定义：NOT NULL）
    IF NEW.member_type IS NULL THEN
        RAISE EXCEPTION 'Validation failed: member_type cannot be null';
    END IF;

    -- [验证4] status 不能为空（表定义：NOT NULL）
    IF NEW.status IS NULL THEN
        RAISE EXCEPTION 'Validation failed: status cannot be null';
    END IF;

    -- [验证5] valid_from 不能为空（表定义：NOT NULL）
    IF NEW.valid_from IS NULL THEN
        RAISE EXCEPTION 'Validation failed: valid_from cannot be null';
    END IF;

    -- [验证6] valid_to 必须 >= valid_from（表定义：CHECK 约束）
    -- 注意：如果表定义中的约束有修改，此处必须同步修改
    IF NEW.valid_to IS NOT NULL AND NEW.valid_to < NEW.valid_from THEN
        RAISE EXCEPTION 'Validation failed: valid_to (%) must be greater than or equal to valid_from (%)', 
            NEW.valid_to, NEW.valid_from;
    END IF;

    -- [验证7] 关联的学校必须存在
    IF NOT EXISTS (SELECT 1 FROM org.education_institution WHERE id = NEW.institution_id) THEN
        RAISE EXCEPTION 'Validation failed: institution with id % does not exist', NEW.institution_id;
    END IF;

    -- [验证8] 关联的人员必须存在
    IF NOT EXISTS (SELECT 1 FROM org.person WHERE id = NEW.person_id) THEN
        RAISE EXCEPTION 'Validation failed: person with id % does not exist', NEW.person_id;
    END IF;

    -- 【关键】所有验证通过后，才生成编号，避免浪费序列号
    NEW.business_identifier := org.gen_member_identifier(NEW.institution_id, 6);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_set_member_identifier
    BEFORE INSERT
    ON org.institution_member
    FOR EACH ROW
EXECUTE FUNCTION org.trg_set_member_identifier();

-- =========================================================
--   3.2 BEFORE UPDATE：防止修改 business_identifier
-- =========================================================
CREATE OR REPLACE FUNCTION org.trg_guard_member_identifier_immutable()
    RETURNS trigger AS
$$
BEGIN
    IF NEW.business_identifier IS DISTINCT FROM OLD.business_identifier THEN
        RAISE EXCEPTION
            'member_identifier is immutable once assigned';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_guard_member_identifier_immutable
    BEFORE UPDATE
    ON org.institution_member
    FOR EACH ROW
EXECUTE FUNCTION org.trg_guard_member_identifier_immutable();

-- =========================================================
-- SaaS Platform Tables
-- 平台级数据，与具体机构无关
-- =========================================================

-- =========================================================
-- Principal Candidate
-- 预校长候选人池
-- 状态：存在即 pending，被选中后即删除
-- =========================================================
CREATE TABLE saas.principal_candidate (
    id              UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    person_id       UUID        NOT NULL UNIQUE REFERENCES org.person(id),
    login_name      text        NOT NULL,  -- 用户通过前端网页设定的登录名
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_principal_candidate_person
    ON saas.principal_candidate(person_id);

-- =========================================================
-- Prospect table moved to V2_3__crm_tables.sql (crm.prospect)
-- =========================================================

