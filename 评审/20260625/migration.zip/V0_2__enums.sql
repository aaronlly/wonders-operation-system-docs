CREATE TYPE enum.org_person_gender_enum AS ENUM (
  'male','female','other','undisclosed'
);

CREATE TYPE enum.org_institution_member_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.org_institution_member_type_enum AS ENUM (
  'student','teacher','staff','contractor','guardian'
);

CREATE TYPE enum.org_institution_role_enum AS ENUM (
  'principal',
  'academic_director',
  'people_admin',
  'finance',
  'it_admin',
  'marketing',
  'operations',
  'sales'
);

CREATE TYPE enum.org_campus_type_enum AS ENUM (
  'physical','virtual'
);

CREATE TYPE enum.org_campus_role_enum AS ENUM (
  'campus_manager','safety','emergency'
);

CREATE TYPE enum.org_guardian_relationship_enum AS ENUM (
  'father','mother','legal_guardian','step_parent','grandparent','relative','other'
);

CREATE TYPE enum.core_resource_type_enum AS ENUM (
  'teacher','student','virtual_room'
);

CREATE TYPE enum.core_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.core_resource_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.core_room_status_enum AS ENUM (
  'active','suspended'
);

CREATE TYPE enum.time_applies_to_type_enum AS ENUM (
  'resource','room'
);

CREATE TYPE enum.time_pattern_cycle_enum AS ENUM (
  'weekly','monthly'
);

CREATE TYPE enum.time_availability_type_enum AS ENUM (
  'available','unavailable'
);

CREATE TYPE enum.time_adjustment_type_enum AS ENUM (
  'one_time_override',
  'temporary_extension',
  'temporary_reduction',
  'swap_time_slot',
  'emergency_closure',
  'exceptional_opening'
);

CREATE TYPE enum.academic_course_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.academic_teaching_mode_enum AS ENUM (
  'onsite','online','hybrid'
);

CREATE TYPE enum.academic_material_type_enum AS ENUM (
  'textbook','workbook','handout','presentation','video','audio','software','online_resource','mixed'
);

CREATE TYPE enum.academic_class_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.event_category_enum AS ENUM (
  'baseline_changing', 'overlay_only'
);

CREATE TYPE enum.academic_study_plan_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.academic_class_member_role_enum AS ENUM (
  'student','teacher','assistant'
);

CREATE TYPE enum.execution_session_type_enum AS ENUM (
  'regular','makeup','trial','cancelled'
);

CREATE TYPE enum.execution_session_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);



CREATE TYPE enum.execution_attendance_status_enum AS ENUM (
  'present','late','left_early','absent_excused','absent_unexcused','cancelled'
);

CREATE TYPE enum.execution_health_status_enum AS ENUM (
  'normal','mild_symptoms','fever','unwell','unknown'
);

CREATE TYPE enum.execution_resource_applies_to_enum AS ENUM (
  'resource','room'
);

CREATE TYPE enum.execution_attendance_recorded_by_role_enum AS ENUM (
  'student',
  'teacher',
  'admin'
);

CREATE TYPE enum.execution_attendance_recording_method_enum AS ENUM (
  'self',
  'admin_override',
  'biometric'
);

CREATE TYPE enum.media_link_target_type_enum AS ENUM (
  'broadcast_message',
  'academic_course',
  'academic_course_version',
  'academic_class',
  'execution_class_session',
  'execution_attendance',
  'contract_snapshot',
  'person_profile'
);

CREATE TYPE enum.messaging_broadcast_content_type_enum AS ENUM (
  'text',
  'mixed'
);

CREATE TYPE enum.messaging_broadcast_status_enum AS ENUM (
  'draft',
  'published',
  'withdrawn'
);

CREATE TYPE enum.messaging_broadcast_target_type_enum AS ENUM (
  'institution',
  'campus',
  'class',
  'resource',
  'institution_role',
  'campus_role'
);

-- 排课失败原因：一级原因
CREATE TYPE enum.scheduling_failure_category_enum AS ENUM (
  'availability_conflict',
  'capacity_conflict',
  'role_constraint_violation',
  'policy_violation',
  'system_constraint'
);

-- 排课失败原因：二级原因
CREATE TYPE enum.scheduling_failure_reason_enum AS ENUM (
  -- availability_conflict
  'teacher_unavailable',
  'student_unavailable',
  'room_unavailable',
  'holiday_blocked',
  'time_baseline_conflict',
  'existing_occupancy_conflict',

  -- capacity_conflict
  'room_capacity_exceeded',
  'max_class_size_exceeded',

  -- role_constraint_violation
  'teacher_not_assigned_to_class',
  'student_not_member_of_class',
  'multiple_teacher_not_allowed',
  'assistant_not_allowed',

  -- policy_violation
  'forbidden_time_window',
  'campus_policy_blocked',
  'manual_lock_active',

  -- system_constraint
  'search_space_exhausted',
  'timeout',
  'internal_error'
);

CREATE TYPE enum.contract_type_enum AS ENUM (
  'student','teacher','other'
);

CREATE TYPE enum.contract_status_enum AS ENUM (
  'draft','active','suspended','completed','cancelled','expired','archived'
);

CREATE TYPE enum.contract_amendment_type_enum AS ENUM (
  'schedule_change',
  'time_baseline_change',
  'course_change',
  'teacher_change',
  'student_change',
  'fee_adjustment',
  'makeup_session_granted',
  'makeup_session_failed',
  'suspension',
  'termination',
  'other'
);

CREATE TYPE enum.point_account_type_enum AS ENUM (
    'student',
    'teacher'
);

CREATE TYPE enum.point_transaction_type_enum AS ENUM (
    'earn',
    'deduct',
    'redeem',
    'refund'
);

CREATE TYPE enum.point_reason_enum AS ENUM (
    'referral_success_student',
    'referral_success_teacher',
    'referral_success_room',

    'makeup_compensation',
    'late_penalty',
    'absence_penalty',
    'cancel_penalty',

    'redeem_free_session',
    'redeem_bonus_payment'
);

CREATE TYPE enum.referral_target_type_enum AS ENUM (
    'student',
    'teacher',
    'room'
);

CREATE TYPE enum.referral_status_enum AS ENUM (
    'pending',
    'approved',
    'rejected',
  'rewarded'
);

CREATE TYPE enum.auth_account_status_enum AS ENUM (
    'active',
    'locked',
    'disabled'
);

CREATE TYPE enum.auth_password_status_enum AS ENUM(
    'initial',
    'active',
    'reset',
    'locked'
);

CREATE TYPE enum.auth_revoked_reason_enum AS ENUM (
    'changed_by_user',
    'reset_by_token',
    'expired',
    'admin_reset'
);

CREATE TYPE enum.workspace_type_enum AS ENUM (
  'academic',
  'teacher',
  'student',
  'guardian',
  'admin'
);

-- Platform-level role (SaaSOperator, system maintainer)
CREATE TYPE enum.platform_role_enum AS ENUM (
  'saas_operator',
  'system_maintainer'
);

-- Account scope: institution-bound vs platform-wide
CREATE TYPE enum.auth_account_scope_enum AS ENUM (
  'institution',
  'platform'
);

-- Prospect lead pipeline status（combined from website form + CRM sales）
CREATE TYPE enum.prospect_status_enum AS ENUM (
    'new',              -- 新提交（website form / manual entry）
    'contacted',        -- 已联系
    'trial_booked',     -- 试课已预约
    'trial_completed',  -- 试课已完成
    'negotiating',      -- 谈判中
    'qualified',        -- 有明确意向，ready to convert
    'converted',        -- 已转化为学生（org.person + contract）
    'lost',             -- 流失（明确放弃）
    'dropped'           -- 彻底无回应
);


CREATE TYPE enum.execution_scheduling_run_reason_enum AS ENUM (
    'initial',
    'reschedule',
    'student_change',
    'teacher_change',
    'manual'
);

-- 执行渠道类型枚举
CREATE TYPE enum.execution_channel_type_enum AS ENUM (
    'onsite',
    'online',
    'hybrid'
);

CREATE TYPE enum.execution_scheduling_run_status_enum AS ENUM (
    'draft',
    'running',
    'paused',
    'confirmed',
    'discarded',
    'failed'
);

CREATE TYPE enum.execution_occupancy_source_enum AS ENUM (
    'planned_session',
    'class_session',
    'manual_block'
);
