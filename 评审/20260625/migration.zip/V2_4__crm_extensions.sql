-- =====================================================
-- V2_4: CRM Extensions - Marketing, Sales, Renewal, Warning
--
-- Schema: crm
-- =====================================================

-- =====================================================
-- 1. Marketing Activity
-- Marketing campaigns and participant tracking.
-- entity_type for participants: 'prospect', 'student', 'guardian'
-- =====================================================
CREATE TABLE crm.marketing_activity (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    title               VARCHAR(255)    NOT NULL,
    description         TEXT,
    activity_type       VARCHAR(30)     NOT NULL DEFAULT 'event'
        CHECK (activity_type IN ('event','campaign','workshop','webinar','other')),
    start_date          TIMESTAMPTZ,
    end_date            TIMESTAMPTZ,
    location            TEXT,
    max_participants    INT,
    status              VARCHAR(15)     NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft','active','completed','cancelled')),
    created_by          UUID            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE TABLE crm.activity_participant (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id  UUID            NOT NULL REFERENCES org.education_institution(id),
    activity_id     UUID            NOT NULL REFERENCES crm.marketing_activity(id) ON DELETE CASCADE,
    entity_type     VARCHAR(30)     NOT NULL
        CHECK (entity_type IN ('prospect','student','guardian')),
    entity_id       UUID            NOT NULL,
    status          VARCHAR(15)     NOT NULL DEFAULT 'registered'
        CHECK (status IN ('registered','attended','cancelled','no_show')),
    check_in_at     TIMESTAMPTZ,
    notes           TEXT,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_activity_participant UNIQUE (activity_id, entity_type, entity_id)
);

CREATE INDEX idx_marketing_institution ON crm.marketing_activity(institution_id);
CREATE INDEX idx_marketing_status ON crm.marketing_activity(status);
CREATE INDEX idx_activity_participant ON crm.activity_participant(activity_id);
CREATE INDEX idx_participant_entity ON crm.activity_participant(entity_type, entity_id);

-- =====================================================
-- 2. Sales Contract & Payment
-- CRM-specific sales contract tracking linked to core contract table.
-- =====================================================
CREATE TABLE crm.sales_contract (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    contract_id         UUID            REFERENCES contract.contract(id),
    prospect_id         UUID            REFERENCES crm.prospect(id),
    student_profile_id  UUID,
    contract_number     VARCHAR(50)     NOT NULL,
    total_amount        DECIMAL(12,2)   NOT NULL DEFAULT 0,
    status              VARCHAR(20)     NOT NULL DEFAULT 'draft'
        CHECK (status IN ('draft','pending','signed','active','completed','cancelled','refunded')),
    signed_at           TIMESTAMPTZ,
    valid_from          DATE            NOT NULL,
    valid_to            DATE,
    notes               TEXT,
    created_by          UUID            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE TABLE crm.sales_payment (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    sales_contract_id   UUID            NOT NULL REFERENCES crm.sales_contract(id) ON DELETE CASCADE,
    amount              DECIMAL(12,2)   NOT NULL,
    payment_date        DATE            NOT NULL,
    payment_method      VARCHAR(20)
        CHECK (payment_method IN ('cash','bank_transfer','credit_card','alipay','wechat','other')),
    transaction_ref     VARCHAR(100),
    notes               TEXT,
    created_by          UUID            NOT NULL,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_sales_contract_institution ON crm.sales_contract(institution_id);
CREATE UNIQUE INDEX uq_sales_contract_number ON crm.sales_contract(institution_id, contract_number);
CREATE INDEX idx_sales_contract_prospect ON crm.sales_contract(prospect_id);
CREATE INDEX idx_sales_payment_contract ON crm.sales_payment(sales_contract_id);
CREATE INDEX idx_sales_payment_institution ON crm.sales_payment(institution_id);

-- =====================================================
-- 3. Renewal Reminder
-- Automated renewal tracking for student contracts.
-- =====================================================
CREATE TABLE crm.renewal_reminder (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    student_profile_id  UUID            NOT NULL,
    sales_contract_id   UUID            REFERENCES crm.sales_contract(id),
    due_date            DATE            NOT NULL,
    amount              DECIMAL(12,2),
    status              VARCHAR(15)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending','resolved','dismissed','overdue')),
    reminded_at         TIMESTAMPTZ,
    resolved_at         TIMESTAMPTZ,
    notes               TEXT,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_renewal_institution ON crm.renewal_reminder(institution_id);
CREATE INDEX idx_renewal_student ON crm.renewal_reminder(student_profile_id);
CREATE INDEX idx_renewal_status ON crm.renewal_reminder(status);

-- =====================================================
-- 4. Churn Warning
-- Early warning system for at-risk students.
-- =====================================================
CREATE TABLE crm.churn_warning (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    institution_id      UUID            NOT NULL REFERENCES org.education_institution(id),
    student_profile_id  UUID            NOT NULL,
    risk_level          VARCHAR(10)     NOT NULL DEFAULT 'medium'
        CHECK (risk_level IN ('low','medium','high')),
    reason              TEXT,
    status              VARCHAR(15)     NOT NULL DEFAULT 'open'
        CHECK (status IN ('open','resolved','dismissed')),
    assigned_to         UUID,
    resolved_at         TIMESTAMPTZ,
    resolution_notes    TEXT,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_churn_institution ON crm.churn_warning(institution_id);
CREATE INDEX idx_churn_student ON crm.churn_warning(student_profile_id);
CREATE INDEX idx_churn_status ON crm.churn_warning(status);
