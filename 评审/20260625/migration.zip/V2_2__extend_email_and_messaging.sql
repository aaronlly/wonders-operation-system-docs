-- =====================================================
-- V2_2: Extend Email Schema + Create Messaging Schema
--
-- 1. email.email_account: SMTP account configuration
-- 2. email.email_delivery: Per-recipient delivery tracking
-- 3. messaging.notification: In-app notification broadcast
-- 4. messaging.notification_recipient: Per-user notification state
-- =====================================================

-- =====================================================
-- 1. Email Account (SMTP configuration)
-- =====================================================
CREATE TABLE email.email_account (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(100)    NOT NULL,
    email           VARCHAR(255)    NOT NULL,
    smtp_host       VARCHAR(255)    NOT NULL,
    smtp_port       INT             NOT NULL DEFAULT 587,
    smtp_user       VARCHAR(255)    NOT NULL,
    smtp_pass_enc   TEXT            NOT NULL,
    smtp_secure     BOOLEAN         NOT NULL DEFAULT false,
    is_default      BOOLEAN         NOT NULL DEFAULT false,
    is_active       BOOLEAN         NOT NULL DEFAULT true,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_email_account_email UNIQUE (email)
);

-- =====================================================
-- 2. Email Delivery (per-recipient tracking)
-- Each email_log may have multiple recipients.
-- This table tracks delivery status per recipient.
-- =====================================================
CREATE TABLE email.email_delivery (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    email_log_id    UUID            NOT NULL REFERENCES email.email_log(id) ON DELETE CASCADE,
    recipient_addr  VARCHAR(255)    NOT NULL,
    recipient_type  VARCHAR(20)     NOT NULL DEFAULT 'to'
        CHECK (recipient_type IN ('to', 'cc', 'bcc')),
    status          VARCHAR(20)     NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'sent', 'delivered', 'bounced', 'failed')),
    opened_at       TIMESTAMPTZ,
    clicked_at      TIMESTAMPTZ,
    error_message   TEXT,
    sent_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_email_delivery_log_id ON email.email_delivery(email_log_id);
CREATE INDEX idx_email_delivery_status ON email.email_delivery(status);

-- =====================================================
-- 3. Notification (in-app broadcast)
-- A notification is a message broadcast to one or more users.
-- entity_type/entity_id: polymorphic link to the source object.
-- =====================================================
CREATE TABLE messaging.notification (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    title           VARCHAR(255)    NOT NULL,
    body            TEXT,
    category        VARCHAR(50)     NOT NULL DEFAULT 'general'
        CHECK (category IN ('general', 'reminder', 'alert', 'task', 'system')),
    priority        VARCHAR(10)     NOT NULL DEFAULT 'normal'
        CHECK (priority IN ('low', 'normal', 'high', 'urgent')),
    entity_type     VARCHAR(50),
    entity_id       UUID,
    created_by      UUID,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now()
);

CREATE INDEX idx_notification_entity ON messaging.notification(entity_type, entity_id);
CREATE INDEX idx_notification_created ON messaging.notification(created_at DESC);

-- =====================================================
-- 4. Notification Recipient (per-user state)
-- =====================================================
CREATE TABLE messaging.notification_recipient (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_id UUID            NOT NULL REFERENCES messaging.notification(id) ON DELETE CASCADE,
    recipient_id    UUID            NOT NULL,
    is_read         BOOLEAN         NOT NULL DEFAULT false,
    read_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),

    CONSTRAINT uq_notif_recipient UNIQUE (notification_id, recipient_id)
);

CREATE INDEX idx_notif_recipient_user ON messaging.notification_recipient(recipient_id, is_read);
